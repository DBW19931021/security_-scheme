from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from typing import Optional
from dataclasses import dataclass
from cryptography.hazmat.primitives import serialization
from .types import EcdhTestData

# 支持的曲线
CURVE_MAP  = {
    "SECP192r1": ec.SECP192R1(),
    "SECP224r1": ec.SECP224R1(),
    # "SECP192k1": ec.SECP192K1(),
    "secp256k1": ec.SECP256K1(),
    # "brainpool224r1": ec.BrainpoolP224R1(),
    # "brainpool320r1": ec.BrainpoolP320R1(),
    # "secp224k1": ec.SECP224K1(),
    "brainpool384r1": ec.BrainpoolP384R1(),
    "brainpool512r1": ec.BrainpoolP512R1(),
    "P-256": ec.SECP256R1(),  # 默认P-256
    "P-384": ec.SECP384R1(),
    "P-521": ec.SECP521R1(),
}

def generate_ecdh_shared_key(
    curve: str = "P-256",
    private_key: Optional[bytes] = None,
    peer_public_key: Optional[bytes] = None,
    test_data: Optional[EcdhTestData] = None
) -> EcdhTestData:
    """
    生成 ECDH 密钥交换的共享密钥。

    该函数根据提供的曲线、私钥和对方公钥计算 ECDH 密钥交换的共享密钥。

    :param curve: 使用的椭圆曲线，默认为 "P-256"。
    :type curve: str
    :param private_key: 用于密钥交换的私钥。如果未提供，将自动生成。
    :type private_key: bytes, 可选
    :param peer_public_key: 对方的公钥，用于计算共享密钥。
    :type peer_public_key: bytes
    :param test_data: 如果提供了测试数据，则直接使用测试数据中的数据。
    :type test_data: EcdhTestData, 可选

    :return: 包含生成的共享密钥以及相关数据的 EcdhTestData 对象。
    :rtype: EcdhTestData

    :example:
    >>> private_key = b'...'  
    >>> peer_public_key = b'...'  
    >>> shared_key_data = generate_ecdh_shared_key(  
    >>>     curve="P-256",  
    >>>     private_key=private_key,  
    >>>     peer_public_key=peer_public_key  
    >>> )  
    >>> print(shared_key_data.shared_key)  
    """
    # 处理测试数据覆盖逻辑
    if test_data is not None:
        curve = test_data.curve
        private_key = test_data.private_key
        peer_public_key = test_data.peer_public_key
        if peer_public_key is None:
            raise ValueError("测试数据必须包含对端公钥")

    # 获取椭圆曲线对象
    curve_obj = CURVE_MAP.get(curve)
    if not curve_obj:
        raise ValueError(f"不支持的曲线类型: {curve}")

    # 自动生成对端公钥（如果未提供且未使用测试数据）
    if test_data is None and peer_public_key is None:
        # 生成对端密钥对
        peer_private_key = ec.generate_private_key(curve_obj)
        peer_public_key = peer_private_key.public_key().public_bytes(
            encoding=serialization.Encoding.X962,
            format=serialization.PublicFormat.UncompressedPoint
        )

    # 验证必要参数
    if peer_public_key is None:
        raise ValueError("必须提供对端公钥")

    # 处理本地私钥逻辑
    if private_key is None:
        # 生成新私钥
        local_private_key = ec.generate_private_key(curve_obj)
        private_key_int = local_private_key.private_numbers().private_value
        key_size_bytes = (curve_obj.key_size + 7) // 8
        private_key = private_key_int.to_bytes(key_size_bytes, 'big')
    else:
        # 验证私钥长度
        key_size_bytes = (curve_obj.key_size + 7) // 8
        if len(private_key) != key_size_bytes:
            raise ValueError(f"无效的私钥长度，应为{key_size_bytes}字节")
        # 从原始字节导入私钥
        private_key_int = int.from_bytes(private_key, 'big')
        local_private_key = ec.derive_private_key(private_key_int, curve_obj)

    # 生成本地公钥（未压缩格式）
    public_key = local_private_key.public_key().public_bytes(
        encoding=serialization.Encoding.X962,
        format=serialization.PublicFormat.UncompressedPoint
    )

    try:
        # 导入对端公钥
        peer_pub_key = ec.EllipticCurvePublicKey.from_encoded_point(
            curve_obj, 
            peer_public_key
        )
    except ValueError as e:
        raise ValueError("无效的对端公钥") from e

    # 计算共享密钥
    try:
        shared_key = local_private_key.exchange(ec.ECDH(), peer_pub_key)
    except ValueError as e:
        raise ValueError("共享密钥计算失败") from e

    return EcdhTestData(
        curve=curve,
        private_key=private_key,
        public_key=public_key,
        peer_public_key=peer_public_key,
        shared_key=shared_key
    )