"""
SM4 CCM模式实现
基于RFC 3610和GB/T 32907-2016标准
"""

import struct
from typing import Optional
from gmssl.sm4 import CryptSM4, SM4_ENCRYPT


class SM4CCM:
    """SM4 CCM (Counter with CBC-MAC) 模式实现"""
    
    def __init__(self, key: bytes, tag_length: int = 16):
        """
        初始化SM4 CCM
        
        :param key: SM4密钥，16字节
        :param tag_length: 认证标签长度，支持4,6,8,10,12,14,16字节
        """
        if len(key) != 16:
            raise ValueError("SM4 key must be 16 bytes")
        if tag_length not in {4, 6, 8, 10, 12, 14, 16}:
            raise ValueError("Invalid tag length for CCM")
            
        self.key = key
        self.tag_length = tag_length
        self.sm4 = CryptSM4()
        self.sm4.set_key(key, SM4_ENCRYPT)
    
    def _xor_bytes(self, a: bytes, b: bytes) -> bytes:
        """字节异或运算"""
        return bytes(x ^ y for x, y in zip(a, b))
    
    def _increment_counter(self, counter: bytes) -> bytes:
        """计数器递增"""
        # 将最后4字节作为计数器递增
        counter_int = struct.unpack('>I', counter[-4:])[0]
        counter_int = (counter_int + 1) & 0xFFFFFFFF
        return counter[:-4] + struct.pack('>I', counter_int)
    
    def _format_nonce(self, nonce: bytes, plaintext_length: int) -> bytes:
        """格式化nonce为CCM格式"""
        nonce_length = len(nonce)
        if not (7 <= nonce_length <= 13):
            raise ValueError("Nonce length must be between 7 and 13 bytes")
        
        # L = 15 - nonce_length (消息长度字段的字节数)
        L = 15 - nonce_length
        if L < 2 or L > 8:
            raise ValueError("Invalid nonce length")
        
        # 格式化B0块: Flags || Nonce || Q
        flags = (self.tag_length - 2) // 2 << 3 | (L - 1)
        
        # Q是明文长度的L字节表示
        Q = plaintext_length.to_bytes(L, 'big')
        
        return struct.pack('B', flags) + nonce + Q
    
    def _format_counter_block(self, nonce: bytes, counter: int = 0) -> bytes:
        """格式化计数器块"""
        nonce_length = len(nonce)
        L = 15 - nonce_length
        
        # 计数器块格式: Flags || Nonce || Counter
        flags = L - 1  # 计数器块的flags只包含L-1
        counter_bytes = counter.to_bytes(L, 'big')
        
        return struct.pack('B', flags) + nonce + counter_bytes
    
    def _cbc_mac(self, nonce: bytes, plaintext: bytes, aad: bytes = b'') -> bytes:
        """计算CBC-MAC"""
        # 准备B0块
        B0 = self._format_nonce(nonce, len(plaintext))
        
        # 如果有AAD，设置相应的flag
        if aad:
            B0 = bytes([B0[0] | 0x40]) + B0[1:]  # 设置AAD flag
        
        # 初始化CBC-MAC
        X = b'\x00' * 16
        
        # 处理B0
        X = self._xor_bytes(X, B0)
        X = self.sm4.crypt_ecb(X)
        
        # 处理AAD
        if aad:
            # AAD长度编码
            aad_len = len(aad)
            if aad_len < 0xFF00:
                aad_block = struct.pack('>H', aad_len) + aad
            else:
                aad_block = struct.pack('>HI', 0xFFFE, aad_len) + aad
            
            # 填充到16字节边界
            if len(aad_block) % 16:
                aad_block += b'\x00' * (16 - len(aad_block) % 16)
            
            # 处理AAD块
            for i in range(0, len(aad_block), 16):
                block = aad_block[i:i+16]
                X = self._xor_bytes(X, block)
                X = self.sm4.crypt_ecb(X)
        
        # 处理明文
        if len(plaintext) % 16:
            plaintext += b'\x00' * (16 - len(plaintext) % 16)
        
        for i in range(0, len(plaintext), 16):
            block = plaintext[i:i+16]
            X = self._xor_bytes(X, block)
            X = self.sm4.crypt_ecb(X)
        
        return X[:self.tag_length]
    
    def _ctr_crypt(self, nonce: bytes, data: bytes) -> bytes:
        """CTR模式加密/解密"""
        result = b''
        counter = 1  # CCM计数器从1开始
        
        for i in range(0, len(data), 16):
            # 构造计数器块
            ctr_block = self._format_counter_block(nonce, counter)
            
            # 加密计数器块
            keystream = self.sm4.crypt_ecb(ctr_block)
            
            # 与数据异或
            block = data[i:i+16]
            result += self._xor_bytes(block, keystream[:len(block)])
            
            counter += 1
        
        return result
    
    def encrypt(self, nonce: bytes, plaintext: bytes, aad: bytes = b'') -> bytes:
        """
        CCM加密
        
        :param nonce: 随机数，7-13字节
        :param plaintext: 明文
        :param aad: 附加认证数据
        :return: 密文+标签
        """
        # 计算认证标签
        tag = self._cbc_mac(nonce, plaintext, aad)
        
        # CTR模式加密明文
        ciphertext = self._ctr_crypt(nonce, plaintext)
        
        # 加密标签 (使用计数器0)
        ctr0_block = self._format_counter_block(nonce, 0)
        keystream = self.sm4.crypt_ecb(ctr0_block)
        encrypted_tag = self._xor_bytes(tag, keystream[:self.tag_length])
        
        return ciphertext + encrypted_tag
    
    def decrypt(self, nonce: bytes, ciphertext_with_tag: bytes, aad: bytes = b'') -> bytes:
        """
        CCM解密
        
        :param nonce: 随机数，必须与加密时相同
        :param ciphertext_with_tag: 密文+标签
        :param aad: 附加认证数据，必须与加密时相同
        :return: 明文
        :raises ValueError: 认证失败时抛出异常
        """
        if len(ciphertext_with_tag) < self.tag_length:
            raise ValueError("Ciphertext too short")
        
        # 分离密文和标签
        ciphertext = ciphertext_with_tag[:-self.tag_length]
        encrypted_tag = ciphertext_with_tag[-self.tag_length:]
        
        # 解密标签
        ctr0_block = self._format_counter_block(nonce, 0)
        keystream = self.sm4.crypt_ecb(ctr0_block)
        tag = self._xor_bytes(encrypted_tag, keystream[:self.tag_length])
        
        # CTR模式解密密文
        plaintext = self._ctr_crypt(nonce, ciphertext)
        
        # 验证认证标签
        expected_tag = self._cbc_mac(nonce, plaintext, aad)
        if tag != expected_tag:
            raise ValueError("Authentication failed")
        
        return plaintext