# -*- coding:utf-8-*-

# 此文件定义核心功能函数，生成测试数据的API

from secrets import token_bytes
from typing import Optional
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from .types import SymmetricTestData
from cryptography.hazmat.primitives.cmac import CMAC
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import padding as crypto_padding
from cryptography.hazmat.primitives.ciphers.aead import AESGCM, AESCCM, ChaCha20Poly1305
from Crypto.Cipher import DES as CryptoDES, ChaCha20 as PyCryptoChaCha20
from Crypto.Hash import CMAC as PyCryptoCMAC
from Crypto.Util.Padding import pad, unpad

def _get_algo_key_length(algo: str, mode: Optional[str] = None) -> int:
    """获取算法对应的密钥长度"""
    match algo:
        case "AES128":
            return 256 if mode == "XTS" else 128
        case "AES192":
            return 192
        case "AES256":
            return 512 if mode == "XTS" else 256
        case "DES":
            return 64
        case "SM4":
            return 256 if mode == "XTS" else 128
        case "TDES-128":
            return 128
        case "TDES-192":
            return 192
        case "CHACHA20":
            return 256
        case _:
            raise ValueError(f"Unsupported algorithm: {algo}")

def _generate_valid_tdes_key(key_length_bytes: int) -> bytes:
    """
    生成有效的 TDES 密钥，避免退化为单 DES

    TDES-128 (16字节): K1 || K2，随机生成（允许 K1 == K2，虽然会退化）
    TDES-192 (24字节): K1 || K2 || K3，要求 K1, K2, K3 不全相同

    Reason: pycryptodome 会检查 TDES-192 密钥是否退化为单 DES（K1 == K2 == K3）
            TDES-128 允许 K1 == K2，因为某些标准测试向量使用此配置
    """
    if key_length_bytes == 16:  # TDES-128
        # 直接生成，允许 K1 == K2
        return token_bytes(16)

    elif key_length_bytes == 24:  # TDES-192
        # 确保 K1, K2, K3 不全相同
        max_attempts = 100
        for _ in range(max_attempts):
            key = token_bytes(24)
            k1, k2, k3 = key[0:8], key[8:16], key[16:24]
            # 只要不是三个都相同就可以
            if not (k1 == k2 == k3):
                return key

        # 如果随机生成失败，手动构造一个有效的密钥
        return token_bytes(8) + token_bytes(8) + token_bytes(8)

    else:
        return token_bytes(key_length_bytes)

    raise ValueError(f"Failed to generate valid TDES key of length {key_length_bytes}")

def _build_pycrypto_cipher(algo: str, mode: str, key: bytes, iv_nonce: bytes = b"", encrypt: bool = True):
    """
    使用 pycryptodome 构造 DES/TDES cipher 实例
    """
    if algo not in ["DES", "TDES-128", "TDES-192"]:
        raise ValueError("Only DES and TDES are supported by pycryptodome backend in this helper")

    mode = mode.upper()

    # 根据算法选择相应的加密模块
    if algo == "DES":
        from Crypto.Cipher import DES as CipherModule
    else:  # TDES-128 or TDES-192
        from Crypto.Cipher import DES3 as CipherModule

        # 验证 TDES 密钥不会退化为单 DES
        # Reason: pycryptodome 要求 TDES-192 的三个子密钥不能完全相同
        # 注意：TDES-128 允许 K1 == K2（虽然退化为单 DES，但某些标准测试向量使用此配置）
        if len(key) == 24:  # TDES-192
            k1, k2, k3 = key[0:8], key[8:16], key[16:24]
            if k1 == k2 == k3:
                raise ValueError("TDES-192 key degenerates to single DES: K1 == K2 == K3")

    if mode == "ECB":
        cipher = CipherModule.new(key, CipherModule.MODE_ECB)
    elif mode == "CBC":
        cipher = CipherModule.new(key, CipherModule.MODE_CBC, iv=iv_nonce)
    elif mode == "CFB":
        cipher = CipherModule.new(key, CipherModule.MODE_CFB, iv=iv_nonce, segment_size=64)
    elif mode == "OFB":
        cipher = CipherModule.new(key, CipherModule.MODE_OFB, iv=iv_nonce)
    elif mode == "CTR":
        from Crypto.Util import Counter
        ctr = Counter.new(64, initial_value=int.from_bytes(iv_nonce, "big"))
        cipher = CipherModule.new(key, CipherModule.MODE_CTR, counter=ctr)
    else:
        raise NotImplementedError(f"Unsupported {algo} mode: {mode}")
    return cipher


def _get_algo_iv_nonce_length(algo: str, mode: str, nonce_length: int = None) -> int:
    """返回特定模式下的 IV 或 nonce 长度

    对于 CHACHA20，支持 8 字节和 12 字节两种 nonce 长度：
    - 8 字节：原始 ChaCha20 规范
    - 12 字节：RFC 7539 规范（默认）
    """
    algo = algo.upper()
    mode = mode.upper()

    if mode in ["ECB", "CMAC", "CBC-MAC"]:
        return 0  # 不需要 IV

    if "AES" in algo or "SM4" in algo:
        # GMAC 的 IV/Nonce 规则与 GCM 相同
        if mode in ["GCM", "GMAC"]:
            return 12  # 标准 GCM/GMAC nonce 长度
        elif mode == "CCM":
            return 13  # 通常为 7~13 字节
        elif mode in ["CBC", "CFB", "OFB", "CTR"]:
            return 16  # 一般等于 block size
        elif mode == "XTS":
            return 16  # tweak 通常也是 16 字节
    elif "TDES" in algo:  # 包括 TDES128 和 TDES192
        if mode in ["CBC", "CFB", "OFB", "CTR"]:
            return 8  # TDES 使用 DES 的 block size（8 字节）
        elif mode in ["GCM", "GMAC"]:
            raise ValueError("GCM/GMAC 模式不支持 TDES")
    elif algo == "DES":
        return 8  # DES block size
    elif algo == "CHACHA20":
        # 如果指定了 nonce 长度，验证是否为支持的长度
        if nonce_length is not None:
            if nonce_length not in [8, 12]:
                raise ValueError("ChaCha20 nonce 长度必须是 8 字节或 12 字节")
            return nonce_length
        # 默认使用 12 字节（RFC 7539）
        return 12

    raise ValueError(f"Unsupported algorithm or mode: {algo}, {mode}")

def generate_symmetric_testdata(
    algo: str,
    mode: str,
    key: bytes = b"",
    padding: str = "NONE",
    iv_nonce: bytes = b"",
    plaintext: bytes | int = 1024,
    aad: Optional[bytes] = None,
    tag_length: Optional[int] = None
) -> SymmetricTestData:
    """
    生成对称加密测试数据。

    该函数为给定的加密算法和模式生成测试数据对象，包含所有进行加密和解密所需的组件，
    如密钥、初始化向量（IV）、nonce、填充类型和明文。

    :param algo: 对称加密算法（例如，'AES'、'DES'）。
    :type algo: str
    :param mode: 加密模式（例如，'ECB'、'CBC'）。
    :type mode: str
    :param key: 加密密钥。默认为空字节串。
    :type key: bytes, optional
    :param padding: 填充方案（例如，'NONE'、'PKCS7'）。默认为 "NONE"。
    :type padding: str, optional
    :param iv_nonce: 初始化向量或 nonce，取决于所选模式。默认为空字节串。
    :type iv_nonce: bytes, optional
    :param plaintext: 要加密的明文。如果提供的是整数，则使用该整数作为随机生成的明文的长度。默认为 1024。
    :type plaintext: bytes 或 int, optional

    :return: 包含加密算法、模式、密钥、填充、IV/nonce 和明文的测试数据对象。
    :rtype: SymmetricTestData

    :example:

    >>> test_data = generate_symmetric_testdata('AES', 'CBC', key=b'somekey', iv_nonce=b'ivnonce', padding='PKCS7', plaintext=b'Hello, world!')
    >>> print(test_data)
    SymmetricTestData(algo='AES', mode='CBC', key=b'somekey', padding='PKCS7', iv_nonce=b'ivnonce', plaintext=b'Hello, world!')
    """
    if algo not in ["AES128", "AES192", "AES256", "DES", "SM4", "TDES-128", "TDES-192", "CHACHA20"]:
        raise ValueError(f"Unsupported algorithm: {algo}")

    if mode not in ["ECB", "CBC", "GCM", "CCM", "CTR", "OFB", "CFB", "CMAC", "GMAC", "CBC-MAC", "XTS", "POLY1305"]:
        raise ValueError(f"Unsupported mode: {mode}")

    if padding not in ["NONE", "PKCS7", "ISO7816", "X923", "ZERO"]:
        raise ValueError(f"Unsupported padding: {padding}")

    key_length = _get_algo_key_length(algo, mode) // 8

    if key and len(key) != key_length:
        raise ValueError(f"Invalid key length: {len(key)}")
    elif not key:
        # 对于 TDES，需要生成有效的密钥（避免退化为单 DES）
        if algo in ["TDES-128", "TDES-192"]:
            key = _generate_valid_tdes_key(key_length)
        else:
            key = token_bytes(key_length)

    if isinstance(plaintext, int):
        plaintext = token_bytes(plaintext)

    # --- GMAC 模式处理逻辑 ---
    if mode == "GMAC":

        if algo not in ["AES128", "AES192", "AES256", "SM4"]:
            raise ValueError("GMAC mode only supports AES, SM4")

        # GMAC 需要一个随机的 nonce
        if not iv_nonce:
            iv_nonce = token_bytes(_get_algo_iv_nonce_length(algo, mode))

        if aad is None:
            aad = token_bytes(16)

        # GMAC 是 GCM 的一种特例，不加密明文，只生成认证标签
        algorithm = _get_cipher_algorithm(algo, key)
        mode_obj = modes.GCM(iv_nonce)
        cipher = Cipher(algorithm, mode_obj)
        encryptor = cipher.encryptor()
        encryptor.authenticate_additional_data(aad)
        encryptor.finalize()  # 不加密数据
        tag = encryptor.tag

        return SymmetricTestData(
            algo=algo,
            mode=mode,
            padding="NONE",
            key=key,
            plaintext=b"",
            ciphertext=b"",            # 不加密
            iv_nonce=iv_nonce,
            aad=aad,
            auth_tag=tag,
            source="by_generator",
        )

    if mode == "CMAC":
        if algo == "DES":
            # 使用 pycryptodome 的标准 CMAC 实现来处理 DES
            # 该实现遵循 NIST SP 800-38B 标准
            cobj = PyCryptoCMAC.new(key, ciphermod=CryptoDES)
            cobj.update(plaintext)
            mac = cobj.digest()

            return SymmetricTestData(
                algo=algo,
                mode=mode,
                padding="NONE",
                key=key,
                plaintext=plaintext,
                ciphertext=mac,
                iv_nonce=iv_nonce,
                auth_tag=b"",
                source="by_generator",
            )
        else:
            algorithm = _get_cipher_algorithm(algo, key)
            cmac = CMAC(algorithm)
            cmac.update(plaintext)
            ciphertext = cmac.finalize()
            return SymmetricTestData(
                algo=algo,
                mode=mode,
                padding=padding,
                key=key,
                plaintext=plaintext,
                ciphertext=ciphertext,
                iv_nonce=b"",
                auth_tag=b"",
                source="by_generator",
            )
    if mode == "CBC-MAC":
        if algo == "DES":
            # # 确保数据长度是8的倍数
            # if len(plaintext) % 8 != 0:
            #     plaintext = pad(plaintext, 8)

            if not iv_nonce:
                iv_nonce = b'\x00' * 8

            cipher = CryptoDES.new(key, CryptoDES.MODE_CBC, iv=iv_nonce)
            ciphertext = cipher.encrypt(plaintext)
            mac = ciphertext[-8:]  # 取最后8字节作为MAC

            return SymmetricTestData(
                algo=algo,
                mode=mode,
                padding="NONE",
                key=key,
                plaintext=plaintext,
                ciphertext=mac,
                iv_nonce=iv_nonce,
                auth_tag=b"",
                source="by_generator",
            )
        else:
            if not iv_nonce:
                iv_nonce = b"\x00" * _get_algo_iv_nonce_length(algo, "CBC")

            algorithm = _get_cipher_algorithm(algo, key)
            mode_obj = modes.CBC(iv_nonce)
            cipher = Cipher(algorithm, mode_obj)
            encryptor = cipher.encryptor()

            # CBC-MAC 不使用填充，要求明文必须是 block size 的倍数
            block_size = algorithm.block_size // 8
            if len(plaintext) % block_size != 0:
                raise ValueError("CBC-MAC requires plaintext length to be multiple of block size")

            ciphertext = encryptor.update(plaintext) + encryptor.finalize()
            mac = ciphertext[-block_size:]  # 最后一块作为 MAC 值

            return SymmetricTestData(
                algo=algo,
                mode=mode,
                padding="NONE",
                key=key,
                plaintext=plaintext,
                ciphertext=mac,
                iv_nonce=iv_nonce,
                auth_tag=b"",
                source="by_generator",
            )
    if mode == "CCM":
        if algo not in ["AES128", "AES192", "AES256", "SM4"]:
            raise ValueError("CCM mode is only supported with AES and SM4 algorithms")
        if aad is None:
            aad = token_bytes(16)
        if not iv_nonce:
            iv_nonce = token_bytes(13)
        if tag_length not in {4, 6, 8, 10, 12, 14, 16}:
            raise ValueError("Invalid tag length for CCM")

        if algo == "SM4":
            from .sm4_ccm import SM4CCM
            sm4ccm = SM4CCM(key, tag_length)
            ciphertext_with_tag = sm4ccm.encrypt(iv_nonce, plaintext, aad)
            # SM4 CCM ciphertext = ciphertext + tag 合并后的结果
            ct, tag = ciphertext_with_tag[:-tag_length], ciphertext_with_tag[-tag_length:]
        else:
            aesccm = AESCCM(key, tag_length)
            ciphertext_with_tag = aesccm.encrypt(iv_nonce, plaintext, aad)
            # AES CCM ciphertext = ciphertext + tag 合并后的结果
            ct, tag = ciphertext_with_tag[:-tag_length], ciphertext_with_tag[-tag_length:]

        return SymmetricTestData(
            algo=algo,
            mode=mode,
            padding="NONE",
            key=key,
            plaintext=plaintext,
            ciphertext=ct,
            iv_nonce=iv_nonce,
            aad=aad,
            auth_tag=tag,
            source="by_generator",
        )

    if mode == "XTS":
        if algo == "SM4":
            from .sm4_xts import SM4XTS
            if not iv_nonce:
                iv_nonce = token_bytes(16)  # XTS tweak是16字节

            sm4xts = SM4XTS(key)
            ciphertext = sm4xts.encrypt(iv_nonce, plaintext)

            return SymmetricTestData(
                algo=algo,
                mode=mode,
                padding="NONE",
                key=key,
                plaintext=plaintext,
                ciphertext=ciphertext,
                iv_nonce=iv_nonce,
                auth_tag=b"",
                source="by_generator",
            )

    if not iv_nonce:
        # 对于 ChaCha20，根据用户传入的 iv_nonce 长度或使用默认长度
        if algo == "CHACHA20":
            iv_nonce = token_bytes(_get_algo_iv_nonce_length(algo, mode))
        else:
            iv_nonce = token_bytes(_get_algo_iv_nonce_length(algo, mode))
        print(f"[generate_symmetric_testdata] (iv_nonce): {iv_nonce.hex()}")

    # 如果是 DES 使用 pycryptodome 实现
    if algo == "DES":
        cipher = _build_pycrypto_cipher(algo, mode, key, iv_nonce, encrypt=True)

        padded_plaintext = _apply_padding(plaintext, 64, padding) if padding != "NONE" else plaintext
        ciphertext = cipher.encrypt(padded_plaintext)

        return SymmetricTestData(
            algo=algo,
            mode=mode,
            padding=padding,
            key=key,
            plaintext=plaintext,
            ciphertext=ciphertext,
            iv_nonce=iv_nonce,
            auth_tag=b"",
            source="by_generator",
        )

    # 如果是 TDES 使用 pycryptodome 实现
    if algo in ["TDES-128", "TDES-192"]:
        cipher = _build_pycrypto_cipher(algo, mode, key, iv_nonce, encrypt=True)

        padded_plaintext = _apply_padding(plaintext, 64, padding) if padding != "NONE" else plaintext
        ciphertext = cipher.encrypt(padded_plaintext)

        return SymmetricTestData(
            algo=algo,
            mode=mode,
            padding=padding,
            key=key,
            plaintext=plaintext,
            ciphertext=ciphertext,
            iv_nonce=iv_nonce,
            auth_tag=b"",
            source="by_generator",
        )

    # 处理ChaCha20-Poly1305特殊情况
    if algo == "CHACHA20" and mode == "POLY1305":
        # 根据已提供的 iv_nonce 长度或使用默认长度
        if not iv_nonce:
            iv_nonce = token_bytes(12)  # 默认使用 12 字节 nonce（RFC 7539）

        nonce_length = len(iv_nonce)

        if tag_length is None:
            tag_length = 16  # Poly1305默认tag长度
        if aad is None:
            aad = token_bytes(12)

        # 根据 nonce 长度选择不同的实现方式
        if nonce_length == 12:
            # 使用 cryptography 库的 ChaCha20Poly1305（RFC 7539，12字节nonce）
            chacha = ChaCha20Poly1305(key)
            ciphertext = chacha.encrypt(iv_nonce, plaintext, aad)
            ct, tag = ciphertext[:-tag_length], ciphertext[-tag_length:]
        elif nonce_length == 8:
            # 使用 PyCryptodome 的 ChaCha20（原始规范，8字节nonce）
            from Crypto.Cipher import ChaCha20_Poly1305 as PyCryptoChaCha20Poly1305
            chacha = PyCryptoChaCha20Poly1305.new(key=key, nonce=iv_nonce)
            chacha.update(aad)
            ct, tag = chacha.encrypt_and_digest(plaintext)
        else:
            raise ValueError(f"ChaCha20 不支持 {nonce_length} 字节的 nonce，仅支持 8 字节或 12 字节")

        return SymmetricTestData(
            algo=algo,
            mode=mode,
            padding="NONE",  # ChaCha20是流密码，不需要填充
            key=key,
            plaintext=plaintext,
            ciphertext=ct,
            iv_nonce=iv_nonce,
            aad=aad,
            auth_tag=tag,
            source="by_generator",
        )

    # 为 GCM 模式生成 AAD（如果用户未提供）
    # Reason: GCM 是认证加密模式，AAD 参与认证但不被加密
    if mode == "GCM":
        if aad is None:
            aad = token_bytes(16)  # 生成16字节随机AAD

    algorithm = _get_cipher_algorithm(algo, key)
    mode_obj = _build_mode(mode, iv_nonce)

    cipher = Cipher(algorithm, mode_obj)
    encryptor = cipher.encryptor()

    # 添加 AAD（如果支持）
    if hasattr(encryptor, "authenticate_additional_data"):
        if mode == "GCM":
            encryptor.authenticate_additional_data(aad)
        else:
            encryptor.authenticate_additional_data(b"")

    padded_plaintext = _apply_padding(plaintext, algorithm.block_size, padding) if padding != "NONE" else plaintext
    ciphertext = encryptor.update(padded_plaintext) + encryptor.finalize()

    auth_tag = getattr(encryptor, "tag", b"")
    if mode == "GCM":
        auth_tag = auth_tag[:tag_length] if tag_length else auth_tag  # 截取 tag_length 字节

    return SymmetricTestData(
        algo=algo,
        mode=mode,
        padding=padding,
        key=key,
        plaintext=plaintext,
        ciphertext=ciphertext,
        iv_nonce=iv_nonce,
        aad=aad if mode == "GCM" else b"",  # GCM 模式包含 AAD,其他模式为空
        auth_tag=auth_tag,
        source="by_generator",
    )


def _build_mode(mode: str, iv_or_nonce: bytes = b"", tag: bytes = b"") -> modes.Mode:
    """
    根据模式构建对应的 mode 实例对象

    参数:
        mode: 模式字符串，例如 CBC、GCM、CCM 等
        iv_or_nonce: 初始化向量或 nonce
        tag: GCM/CCM 模式的认证标签（用于解密）

    返回:
        对应的 modes.Mode 实例
    """
    mode = mode.upper()

    if mode == "ECB":
        return modes.ECB()
    elif mode == "CBC":
        return modes.CBC(iv_or_nonce)
    elif mode == "CFB":
        return modes.CFB(iv_or_nonce)
    elif mode == "OFB":
        return modes.OFB(iv_or_nonce)
    elif mode == "CTR":
        return modes.CTR(iv_or_nonce)
    elif mode == "XTS":
        return modes.XTS(iv_or_nonce)
    elif mode in ["GCM", "GMAC"]: # GMAC 使用 GCM 的 mode 对象
        return modes.GCM(iv_or_nonce, tag) if tag else modes.GCM(iv_or_nonce)
    elif mode == "CCM":
        return modes.CCM(iv_or_nonce, tag) if tag else modes.CCM(iv_or_nonce)
    else:
        raise ValueError(f"Unsupported cipher mode: {mode}")

def _apply_padding(data: bytes, block_size: int, padding_type: str) -> bytes:
    """应用不同类型的填充"""
    block_size_bytes = block_size // 8
    pad_len = block_size_bytes - (len(data) % block_size_bytes)
    if pad_len == 0:
        pad_len = block_size_bytes  # 块对齐时也要补一整块

    if padding_type == "PKCS7":
        padder = crypto_padding.PKCS7(block_size).padder()
        return padder.update(data) + padder.finalize()

    elif padding_type == "ISO7816":
        return data + b'\x80' + b'\x00' * (pad_len - 1)

    elif padding_type == "X923":
        return data + b'\x00' * (pad_len - 1) + bytes([pad_len])

    elif padding_type == "ZERO":
        return data + b'\x00' * pad_len

    elif padding_type == "NONE":
        if len(data) % block_size_bytes != 0:
            raise ValueError("Data not block-aligned and padding is NONE")
        return data

    raise ValueError(f"Unsupported padding type: {padding_type}")

def _get_algo_block_size(algo: str) -> int:
    if algo.startswith("AES") or algo == "SM4": return 128
    if algo.startswith("TDES") or algo == "DES": return 64
    raise ValueError(f"Unsupported block size query for algo: {algo}")


def _build_cipher(algo: str, mode: str, key: bytes, iv: bytes, tag: bytes = b"") -> Cipher:
    algorithm = _get_cipher_algorithm(algo, key)

    if mode == "CBC":
        mode_ = modes.CBC(iv)
    elif mode == "GCM":
        mode_ = modes.GCM(iv, tag or None)
    elif mode == "CCM":
        mode_ = modes.CCM(iv, tag or None)
    elif mode == "XTS":
        mode_ = modes.XTS(iv)
    elif mode == "ECB":
        mode_ = modes.ECB()
    elif mode == "CTR":
        mode_ = modes.CTR(iv)
    elif mode == "CFB":
        mode_ = modes.CFB(iv)
    elif mode == "OFB":
        mode_ = modes.OFB(iv)
    else:
        raise NotImplementedError(f"Unsupported mode: {mode}")

    return Cipher(algorithm, mode_)


def verify_symmetric_testdata(
    testdata: SymmetricTestData,
) -> bool:
    """
    验证对称加密测试数据的有效性。

    该函数接受一个对称加密测试数据对象，验证其中包含的加密算法、模式、密钥、填充方案、IV/nonce 和明文是否符合预期的要求。

    :param testdata: 对称加密测试数据对象，包含加密算法、模式、密钥、填充、IV/nonce 和明文。
    :type testdata: SymmetricTestData

    :return: 如果测试数据有效，返回 `True`，否则返回 `False`。
    :rtype: bool

    :example:

    >>> test_data = SymmetricTestData(algo='AES', mode='CBC', key=b'somekey', padding='PKCS7', iv_nonce=b'ivnonce', plaintext=b'Hello, world!')
    >>> is_valid = verify_symmetric_testdata(test_data)
    >>> print(is_valid)
    True
    """
    padding = testdata.padding
    mode = testdata.mode
    algorithm = testdata.algo
    # --- GMAC 模式验证逻辑 ---
    if mode == "GMAC":
        if algorithm not in ["AES128", "AES192", "AES256", "SM4"]:
            raise ValueError("GMAC mode only supports AES, SM4")
        try:
            algorithm_obj = _get_cipher_algorithm(algorithm, testdata.key)
            mode_obj = modes.GCM(testdata.iv_nonce, testdata.auth_tag)
            cipher = Cipher(algorithm_obj, mode_obj)
            decryptor = cipher.decryptor()
            decryptor.authenticate_additional_data(testdata.aad)
            decryptor.finalize()
            return True
        except Exception:
            return False
    if mode == "CMAC":
        if algorithm == "DES":
            # 使用 pycryptodome 的标准 CMAC 实现进行验证
                cobj = PyCryptoCMAC.new(testdata.key, ciphermod=CryptoDES)
                cobj.update(testdata.plaintext)
                try:
                    # verify 方法会进行安全比较，并在失败时抛出异常
                    cobj.verify(testdata.ciphertext)
                    return True
                except ValueError:
                    # MAC 不匹配
                    return False
        else:
            algo_obj = _get_cipher_algorithm(algorithm, testdata.key)
            cmac = CMAC(algo_obj)
            cmac.update(testdata.plaintext)
            try:
                cmac.verify(testdata.ciphertext)
                return True
            except InvalidSignature:
                return False
    if mode == "CBC-MAC":
        if algorithm == "DES":
            # 使用 pycryptodome 验证 DES-CBC-MAC
            cipher = CryptoDES.new(testdata.key, CryptoDES.MODE_CBC, iv=testdata.iv_nonce)

            computed = cipher.encrypt(testdata.plaintext)
            return computed[-8:] == testdata.ciphertext
        else:
            algorithm = _get_cipher_algorithm(algorithm, testdata.key)
            mode_obj = modes.CBC(testdata.iv_nonce)
            cipher = Cipher(algorithm, mode_obj)
            encryptor = cipher.encryptor()

            block_size = algorithm.block_size // 8
            if len(testdata.plaintext) % block_size != 0:
                return False

            computed = encryptor.update(testdata.plaintext) + encryptor.finalize()
            return computed[-block_size:] == testdata.ciphertext

    if algorithm == "DES":
        cipher = _build_pycrypto_cipher(algorithm, mode, testdata.key, testdata.iv_nonce, encrypt=False)
        decrypted = cipher.decrypt(testdata.ciphertext)

        if padding != "NONE":
            decrypted = _remove_padding(decrypted, 64, padding, len(testdata.plaintext))
        return decrypted == testdata.plaintext

    if algorithm in ["TDES-128", "TDES-192"]:
        cipher = _build_pycrypto_cipher(algorithm, mode, testdata.key, testdata.iv_nonce, encrypt=False)
        decrypted = cipher.decrypt(testdata.ciphertext)

        if padding != "NONE":
            decrypted = _remove_padding(decrypted, 64, padding, len(testdata.plaintext))
        return decrypted == testdata.plaintext

    print(f"\n[VERIFY] algo={algorithm}, mode={mode}, padding={padding}")
    print(f"[VERIFY] key: {testdata.key.hex()}")
    print(f"[VERIFY] ciphertext: {testdata.ciphertext.hex()}")
    print(f"[VERIFY] iv_nonce: {testdata.iv_nonce.hex()}")
    print(f"[VERIFY] auth_tag: {testdata.auth_tag.hex()}")
    # 处理ChaCha20-Poly1305特殊情况
    if algorithm == "CHACHA20" and mode == "POLY1305":
        nonce_length = len(testdata.iv_nonce)

        try:
            if nonce_length == 12:
                # 使用 cryptography 库的 ChaCha20Poly1305（RFC 7539，12字节nonce）
                chacha = ChaCha20Poly1305(testdata.key)
                decrypted = chacha.decrypt(
                    testdata.iv_nonce,
                    testdata.ciphertext + testdata.auth_tag,
                    testdata.aad
                )
            elif nonce_length == 8:
                # 使用 PyCryptodome 的 ChaCha20（原始规范，8字节nonce）
                from Crypto.Cipher import ChaCha20_Poly1305 as PyCryptoChaCha20Poly1305
                chacha = PyCryptoChaCha20Poly1305.new(key=testdata.key, nonce=testdata.iv_nonce)
                chacha.update(testdata.aad)
                decrypted = chacha.decrypt_and_verify(testdata.ciphertext, testdata.auth_tag)
            else:
                raise ValueError(f"ChaCha20 不支持 {nonce_length} 字节的 nonce，仅支持 8 字节或 12 字节")

            return decrypted == testdata.plaintext
        except Exception:
            return False

    # 处理AES CCM特殊情况
    if algorithm in ["AES128", "AES192", "AES256"] and mode == "CCM":
        try:
            aesccm = AESCCM(testdata.key, len(testdata.auth_tag))
            decrypted = aesccm.decrypt(
                testdata.iv_nonce,
                testdata.ciphertext + testdata.auth_tag,
                testdata.aad or b""
            )
            return decrypted == testdata.plaintext
        except Exception:
            return False

    # 处理SM4 CCM特殊情况
    if algorithm == "SM4" and mode == "CCM":
        from .sm4_ccm import SM4CCM
        try:
            sm4ccm = SM4CCM(testdata.key, len(testdata.auth_tag))
            decrypted = sm4ccm.decrypt(
                testdata.iv_nonce,
                testdata.ciphertext + testdata.auth_tag,
                testdata.aad or b""
            )
            return decrypted == testdata.plaintext
        except Exception:
            return False

    # 处理SM4 XTS特殊情况
    if algorithm == "SM4" and mode == "XTS":
        from .sm4_xts import SM4XTS
        try:
            sm4xts = SM4XTS(testdata.key)
            decrypted = sm4xts.decrypt(testdata.iv_nonce, testdata.ciphertext)
            return decrypted == testdata.plaintext
        except Exception:
            return False

    cipher = _build_cipher(algorithm, mode, testdata.key, testdata.iv_nonce, testdata.auth_tag)
    decryptor = cipher.decryptor()

    try:
        if hasattr(decryptor, "authenticate_additional_data"):
            # 为 GCM 模式使用 testdata.aad，其他模式使用空 AAD
            # Reason: GCM 模式的 AAD 必须与加密时的 AAD 一致，才能验证成功
            if mode == "GCM" and testdata.aad:
                decryptor.authenticate_additional_data(testdata.aad)
            else:
                decryptor.authenticate_additional_data(b"")

        decrypted_data = decryptor.update(testdata.ciphertext) + decryptor.finalize()

        print(f"[VERIFY] decrypted (raw): {decrypted_data.hex()}")

        if padding != "NONE":
            decrypted_data = _remove_padding(decrypted_data, cipher.algorithm.block_size, padding, len(testdata.plaintext))
            print(f"[VERIFY] decrypted (unpadded): {decrypted_data.hex()}")
        print(f"[VERIFY] decrypted (_remove_padding): {decrypted_data.hex()}")
        print(f"[VERIFY] original plaintext: {testdata.plaintext.hex()}")

        return decrypted_data == testdata.plaintext
    except Exception:
        # GCM 模式下 AAD 或 tag 不匹配会抛出异常
        return False

def _remove_padding(data: bytes, block_size: int, padding_type: str, known_length: int = None) -> bytes:
    print(f"[UNPAD] type={padding_type}, block_size={block_size}, data={data.hex()}")
    if padding_type == "PKCS7":
        unpadder = crypto_padding.PKCS7(block_size).unpadder()
        return unpadder.update(data) + unpadder.finalize()

    elif padding_type == "X923":
        pad_len = data[-1]
        if pad_len == 0 or pad_len > len(data):
            raise ValueError("Invalid X9.23 padding")
        if any(data[-pad_len:-1]) != 0:
            raise ValueError("Invalid X9.23 padding zeros")
        return data[:-pad_len]

    elif padding_type == "ISO7816":
        try:
            index = data.rindex(b'\x80')
        except ValueError:
            raise ValueError("Invalid ISO7816 padding: 0x80 marker not found")
        if data[index + 1:] != b'\x00' * (len(data) - index - 1):
            raise ValueError("Invalid ISO7816 padding: not all zero after 0x80")
        return data[:index]

    elif padding_type == "ZERO":
        if known_length is not None:
            return data[:known_length]
        else:
            return data.rstrip(b'\x00')

    elif padding_type == "NONE":
        return data

    raise NotImplementedError(f"Unsupported padding: {padding_type}")


def _get_cipher_algorithm(algo: str, key: bytes):
    """返回加密算法对象"""
    algo = algo.upper()
    if "AES" in algo:
        return algorithms.AES(key)
    elif "SM4" in algo:
        return algorithms.SM4(key)
    elif "TDES" in algo:
        return algorithms.TripleDES(key)
    elif "DES" == algo:
        return algorithms.DES(key)
    elif "CHACHA20" == algo:
        return None  # ChaCha20使用专门的AEAD接口，不通过Cipher接口
    else:
        raise ValueError(f"Unsupported algorithm: {algo}")
