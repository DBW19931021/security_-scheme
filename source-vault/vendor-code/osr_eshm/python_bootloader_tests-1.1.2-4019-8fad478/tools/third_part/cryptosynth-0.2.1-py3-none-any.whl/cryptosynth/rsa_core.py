from dataclasses import dataclass
from typing import Union
from secrets import token_bytes
from Cryptodome.PublicKey import RSA
from Cryptodome.Signature import pkcs1_15, pss
from Cryptodome.Cipher import PKCS1_OAEP, PKCS1_v1_5
from Cryptodome.Hash import SHA1, SHA224, SHA256, SHA384, SHA512
from Cryptodome.Util.number import bytes_to_long, long_to_bytes
from .types import RsaSignTestData, RsaEncryptTestData


# Reason: 为 SHA512/224 和 SHA512/256 创建哈希模块包装类，使其能与 PKCS1_OAEP 兼容
class _SHA512_Truncated:
    """SHA-512 截断版本的哈希模块包装类"""
    def __init__(self, truncate_bits: str):
        self.truncate = truncate_bits
        self.digest_size = 28 if truncate_bits == '224' else 32

    def new(self, data=None):
        """创建新的哈希对象"""
        if data is None:
            return SHA512.new(truncate=self.truncate)
        return SHA512.new(data, truncate=self.truncate)

# 创建全局的哈希模块实例
SHA512_224 = _SHA512_Truncated('224')
SHA512_256 = _SHA512_Truncated('256')



def generate_rsa_sign_testdata( 
    data: bytes | int = 1024,
    hash_alg: str = "SHA256",
    mode: str = "PKCS1v15",
    e: bytes = b"",
    n: bytes = b"",
    d: bytes = b"",
    p: bytes = b"",
    q: bytes = b"",
    dP: bytes = b"",
    dQ: bytes = b"",
    qInv: bytes = b"",
    key_size: int = 2048
) -> RsaSignTestData:
    """
    生成 RSA 签名测试数据。

    该函数根据提供的参数生成 RSA 签名所需的测试数据，包括数据、哈希算法、模式、密钥等，用于后续的签名和验签测试。

    :param data: 用于签名的消息数据。如果提供整数，将生成该长度的随机数据。默认为 1024。
    :type data: bytes 或 int
    :param hash_alg: 用于签名的哈希算法，默认为 "SHA256"。
    :type hash_alg: str
    :param mode: 使用的签名模式，默认为 "PKCS1v15"。
    :type mode: str
    :param e: 公钥指数（e）。
    :type e: bytes
    :param n: 公钥模数（n）。
    :type n: bytes
    :param d: 私钥指数（d）。
    :type d: bytes
    :param p: p 是 RSA 中的一个质数。
    :type p: bytes
    :param q: q 是 RSA 中的另一个质数。
    :type q: bytes
    :param dP: dP 是私钥指数与 p 的模逆。
    :type dP: bytes
    :param dQ: dQ 是私钥指数与 q 的模逆。
    :type dQ: bytes
    :param qInv: qInv 是 q 的逆元素。
    :type qInv: bytes
    :param key_size: 密钥的大小（位），默认为 2048 位。
    :type key_size: int

    :return: 包含生成的签名测试数据（包括数据、签名算法、私钥、公钥等）。
    :rtype: RsaSignTestData

    :example:
    >>> private_key = b'...'  
    >>> public_key = b'...'  
    >>> sign_data = generate_rsa_sign_testdata(private_key=private_key, public_key=public_key)  
    >>> print(sign_data.signature)  
    """
    # 随机明文生成
    if isinstance(data, int):
        data = token_bytes(data)

    # 判断是否需要生成新密钥
    if not (n and e and d):
        key = RSA.generate(key_size)
        n = key.n.to_bytes((key.n.bit_length() + 7) // 8, 'big')
        e = key.e.to_bytes((key.e.bit_length() + 7) // 8, 'big')
        d = key.d.to_bytes((key.d.bit_length() + 7) // 8, 'big')
        p = key.p.to_bytes((key.p.bit_length() + 7) // 8, 'big')
        q = key.q.to_bytes((key.q.bit_length() + 7) // 8, 'big')
        dP = key.dp.to_bytes((key.dp.bit_length() + 7) // 8, 'big')
        dQ = key.dq.to_bytes((key.dq.bit_length() + 7) // 8, 'big')
        qInv = key.invq.to_bytes((key.invq.bit_length() + 7) // 8, 'big')
    else:
        # Reason: 对于NoPadding模式，不需要构造RSA key对象，直接使用原始运算
        # 只有PKCS1v15和PSS模式需要key对象
        if mode.upper() != "NOPADDING":
            # 提取 int
            n_int = int.from_bytes(n, 'big')
            e_int = int.from_bytes(e, 'big')
            d_int = int.from_bytes(d, 'big')

            # 是否可用CRT模式
            crt_complete = all([p, q, dP, dQ, qInv])
            if crt_complete:
                key = RSA.construct((
                    n_int,
                    e_int,
                    d_int,
                    int.from_bytes(p, 'big'),
                    int.from_bytes(q, 'big'),
                ))
            else:
                key = RSA.construct((n_int, e_int, d_int))

    # Reason: 统一哈希计算，避免代码重复
    # 哈希算法映射表
    hash_map = {
        "SHA1": SHA1, "SHA224": SHA224, "SHA256": SHA256,
        "SHA384": SHA384, "SHA512": SHA512,
        "SHA512/224": lambda: SHA512.new(truncate='224'),
        "SHA512/256": lambda: SHA512.new(truncate='256')
    }
    # Reason: SHA512/224 和 SHA512/256 使用 lambda 函数创建，需要调用后再 update
    hash_alg_upper = hash_alg.upper()
    if hash_alg_upper in ["SHA512/224", "SHA512/256"]:
        hfunc = hash_map[hash_alg_upper]()
        hfunc.update(data)
    else:
        hfunc = hash_map[hash_alg_upper].new(data)

    # 签名模式
    if mode.upper() == "PKCS1V15":
        signer = pkcs1_15.new(key)
        signature = signer.sign(hfunc)
    elif mode.upper() == "PSS":
        signer = pss.new(key)
        signature = signer.sign(hfunc)
    elif mode.upper() == "NOPADDING":
        # Reason: NoPadding模式先计算哈希，然后对哈希值进行原始RSA运算（不添加PKCS填充）
        digest = hfunc.digest()

        # 将哈希值转换为整数
        m_int = int.from_bytes(digest, 'big')
        n_int = int.from_bytes(n, 'big')

        # 验证哈希值必须 < n
        if m_int >= n_int:
            raise ValueError(f"Hash digest must be less than modulus n for NoPadding mode")

        # 原始RSA签名: s = hash^d mod n
        d_int = int.from_bytes(d, 'big')
        s_int = pow(m_int, d_int, n_int)

        # 转换为bytes，长度与n相同
        signature = s_int.to_bytes((n_int.bit_length() + 7) // 8, 'big')
    else:
        raise ValueError(f"Unsupported signature mode: {mode}")

    return RsaSignTestData(
        data=data,
        hash_alg=hash_alg.upper(),
        mode=mode.upper(),
        e=e,
        n=n,
        d=d,
        p=p,
        q=q,
        dP=dP,
        dQ=dQ,
        qInv=qInv,
        signature=signature
    )


def verify_rsa_signature(test_data: Union[RsaSignTestData, bytes, bytes, str, str, bytes, bytes, int]) -> bool:
    """
    验证 RSA 签名。

    该函数根据提供的测试数据，使用公钥验证签名的有效性。

    :param test_data: 测试数据，可以是 `RsaSignTestData` 类型对象，或者包含以下元素的元组或列表：
        - 签名数据（bytes）
        - 待验证的数据（bytes）
        - 哈希算法（str）
        - 签名模式（str）
        - 公钥（bytes）
        - salt长度（int）
    :type test_data: RsaSignTestData | tuple | list

    :return: 如果签名验证通过，返回 True；否则返回 False。
    :rtype: bool

    :example:
    >>> test_data = RsaSignTestData(signature=b'...', data=b'...', hash_alg='SHA256', mode='PKCS1v15', public_key=b'...', salt_len=10)  
    >>> is_valid = verify_rsa_signature(test_data)  
    >>> print(is_valid)  # 输出: True 或 False  
    """
    # 处理参数重载：允许直接传入 RsaSignTestData 或单独参数
    if isinstance(test_data, RsaSignTestData):
        data = test_data.data
        signature = test_data.signature
        hash_alg = test_data.hash_alg
        mode = test_data.mode
        e = test_data.e
        n = test_data.n
        salt_len =len(test_data.salt) 

    else:
        # 假设参数顺序为 data, signature, hash_alg, mode, e, n, salt_len
        data, signature, hash_alg, mode, e, n , salt_len = test_data
    try:
        # 构造 RSA 公钥（不需要 d）
        n_int = int.from_bytes(test_data.n, 'big')
        e_int = int.from_bytes(test_data.e, 'big')
        pubkey = RSA.construct((n_int, e_int))

        # Reason: 统一哈希计算，避免代码重复
        # 哈希算法映射表
        hash_map = {
            "SHA1": SHA1,
            "SHA224": SHA224,
            "SHA256": SHA256,
            "SHA384": SHA384,
            "SHA512": SHA512,
            "SHA512/224": lambda: SHA512.new(truncate='224'),
            "SHA512/256": lambda: SHA512.new(truncate='256')
        }
        # Reason: SHA512/224 和 SHA512/256 使用 lambda 函数创建，需要调用后再 update
        hash_alg_upper = test_data.hash_alg.upper()
        if hash_alg_upper in ["SHA512/224", "SHA512/256"]:
            hfunc = hash_map[hash_alg_upper]()
            hfunc.update(test_data.data)
        else:
            hfunc = hash_map[hash_alg_upper].new(test_data.data)

        # 验签
        if test_data.mode.upper() == "PKCS1V15":
            verifier = pkcs1_15.new(pubkey)
            verifier.verify(hfunc, test_data.signature)
        elif test_data.mode.upper() == "PSS":
            if(salt_len == 0):
                verifier = pss.new(pubkey)
            else:
                verifier = pss.new(pubkey,salt_bytes=salt_len)
            verifier.verify(hfunc, test_data.signature)
        elif test_data.mode.upper() == "NOPADDING":
            # Reason: NoPadding模式先对数据计算哈希，然后对签名进行原始RSA运算验证
            digest = hfunc.digest()

            # 原始RSA验签: hash' = s^e mod n
            s_int = int.from_bytes(test_data.signature, 'big')
            n_int = int.from_bytes(test_data.n, 'big')
            e_int = int.from_bytes(test_data.e, 'big')
            hash_recovered = pow(s_int, e_int, n_int)

            # 将恢复的整数转换为bytes进行比较
            hash_int = int.from_bytes(digest, 'big')

            if hash_recovered != hash_int:
                raise ValueError("Signature verification failed")
        else:
            raise ValueError(f"Unsupported mode: {test_data.mode}")

        return True
    except (ValueError, TypeError):
        return False

# ----------------------------------------------
# 核心加密接口
# ----------------------------------------------

def generate_rsa_encrypt_testdata(
    plaintext: Union[bytes, int] = 125,
    mode: str = "OAEP",
    hash_alg: str = "SHA256",
    label: bytes = b"",
    e: bytes = b"",
    n: bytes = b"",
    d: bytes = b"",
    p: bytes = b"",
    q: bytes = b"",
    dP: bytes = b"",
    dQ: bytes = b"",
    qInv: bytes = b"",
    key_size: int = 2048
) -> RsaEncryptTestData:
    """
    生成 RSA 加密测试数据
    :param plaintext: 明文（bytes 或长度，默认随机生成）
    :param mode: 加密模式 "PKCS1V15" 或 "OAEP"
    :param hash_alg: OAEP 使用的哈希算法（"SHA1", "SHA256" 等）
    :param label: OAEP 模式下使用的可选标签（默认为空字节串）
    :param e,n,d,p,q,dP,dQ,qInv: 可选密钥参数
    :param key_size: 若未提供密钥，生成的新密钥长度
    :return: RsaEncryptTestData 实例
    """
    # 生成随机明文（如果输入是长度）
    if isinstance(plaintext, int):
        plaintext = token_bytes(plaintext)

    # 生成或解析密钥
    if not (n and e):
        # 生成新密钥
        key = RSA.generate(key_size)
        n = key.n.to_bytes((key.n.bit_length() +7 ) //8, 'big')
        e = key.e.to_bytes((key.e.bit_length() +7 ) //8, 'big')
        d = key.d.to_bytes((key.d.bit_length() +7 ) //8, 'big')
        p = key.p.to_bytes((key.p.bit_length() +7 ) //8, 'big')
        q = key.q.to_bytes((key.q.bit_length() +7 ) //8, 'big')
        dP = key.dp.to_bytes((key.dp.bit_length() +7 ) //8, 'big')
        dQ = key.dq.to_bytes((key.dq.bit_length() +7 ) //8, 'big')
        qInv = key.invq.to_bytes((key.invq.bit_length() +7 ) //8, 'big')
    else:
        # 使用现有公钥参数构建公钥
        n_int = bytes_to_long(n)
        e_int = bytes_to_long(e)
        key = RSA.construct((n_int, e_int))

    # 加密操作
    if mode.upper() == "PKCS1V15":
        cipher = PKCS1_v1_5.new(key)
        ciphertext = cipher.encrypt(plaintext)
    elif mode.upper() == "OAEP":
        # 处理 OAEP 哈希算法
        hash_map = {
            "SHA1": SHA1, "SHA224": SHA224, "SHA256": SHA256,
            "SHA384": SHA384, "SHA512": SHA512,
            "SHA512/224": SHA512_224,
            "SHA512/256": SHA512_256
        }
        hash_cls = hash_map.get(hash_alg.upper())
        if not hash_cls:
            raise ValueError(f"Unsupported OAEP hash: {hash_alg}")
        # Reason: OAEP 支持可选的 label 参数，用于绑定加密上���文
        cipher = PKCS1_OAEP.new(key, hash_cls, label=label)
        ciphertext = cipher.encrypt(plaintext)
    else:
        raise ValueError(f"Unsupported encryption mode: {mode}")

    return RsaEncryptTestData(
        plaintext=plaintext,
        ciphertext=ciphertext,
        mode=mode.upper(),
        hash_alg=hash_alg.upper(),
        label=label,
        e=e,
        n=n,
        d=d,
        p=p,
        q=q,
        dP=dP,
        dQ=dQ,
        qInv=qInv
    )

# ----------------------------------------------
# 解密验证接口
# ----------------------------------------------

def verify_rsa_decryption(test_data: Union[RsaEncryptTestData, bytes, bytes, str, str, bytes, bytes]) -> bool:
    """
    RSA 解密验证
    :param test_data: 可直接传入 RsaEncryptTestData，或单独参数：
        ciphertext: 密文 bytes
        mode: 加密模式
        hash_alg: OAEP 的哈希算法
        d: 私钥指数 bytes
        n: 模数 bytes
        (可选 CRT 参数 p, q, dP, dQ, qInv)
    :return: 解密后的明文是否匹配原始明文
    """
    # 参数解析
    if isinstance(test_data, RsaEncryptTestData):
        ciphertext = test_data.ciphertext
        mode = test_data.mode
        hash_alg = test_data.hash_alg
        label = test_data.label
        d = test_data.d
        n = test_data.n
        p = test_data.p
        q = test_data.q
        dP = test_data.dP
        dQ = test_data.dQ
        qInv = test_data.qInv
        expected_plaintext = test_data.plaintext
    else:
        # 参数顺序: ciphertext, mode, hash_alg, d, n, [p, q, dP, dQ, qInv]
        ciphertext, mode, hash_alg, label, d, n, p, q, dP, dQ, qInv, expected_plaintext = test_data

    # 构建私钥
    n_int = bytes_to_long(n)
    e_int = 65537  # 公钥指数通常为固定值，此处简化处理
    d_int = bytes_to_long(d)
    
    # 是否使用 CRT 参数加速解密
    crt_params = [p, q, dP, dQ, qInv]
    if all(len(x) > 0 for x in crt_params):
        p_int = bytes_to_long(p)
        q_int = bytes_to_long(q)
        dP_int = bytes_to_long(dP)
        dQ_int = bytes_to_long(dQ)
        qInv_int = bytes_to_long(qInv)
        key = RSA.construct((
            n_int, e_int, d_int
        ))
    else:
        key = RSA.construct((n_int, e_int, d_int))

    # 解密操作
    try:
        if mode.upper() == "PKCS1V15":
            cipher = PKCS1_v1_5.new(key)
            plaintext = cipher.decrypt(ciphertext, sentinel=None)
        elif mode.upper() == "OAEP":
            hash_map = {
                "SHA1": SHA1, "SHA224": SHA224, "SHA256": SHA256,
                "SHA384": SHA384, "SHA512": SHA512,
                "SHA512/224": SHA512_224,
                "SHA512/256": SHA512_256
            }
            hash_cls = hash_map.get(hash_alg.upper())
            # Reason: OAEP 解密时必须使用与加密时相同的 label 参数
            cipher = PKCS1_OAEP.new(key, hash_cls, label=label)
            plaintext = cipher.decrypt(ciphertext)
        else:
            raise ValueError(f"Unsupported mode: {mode}")
    except (ValueError, TypeError):
        return False

    return plaintext == expected_plaintext
