from typing import Optional
from dataclasses import dataclass
from Cryptodome.Random.random import getrandbits
from Cryptodome.Random import get_random_bytes
from Cryptodome.Hash import SHA256
from .types import DhTestData

def generate_dh_shared_key(
    p: Optional[bytes] = None,
    g: Optional[bytes] = None,
    private_key: Optional[bytes] = None,
    peer_public_key: Optional[bytes] = None,
    key_size: int = 2048
) -> DhTestData:
    """
    生成 Diffie-Hellman 密钥交换的共享密钥。

    该函数生成 Diffie-Hellman 密钥交换的共享密钥，使用提供的质数模数 `p`、生成元 `g`，
    私钥以及对方的公钥。

    :param p: 用于 Diffie-Hellman 密钥交换的质数模数。如果未提供，将使用默认值。
    :type p: bytes, 可选
    :param g: 用于 Diffie-Hellman 密钥交换的生成元。如果未提供，将使用默认值。
    :type g: bytes, 可选
    :param private_key: 用于密钥交换的私钥。如果未提供，将自动生成。
    :type private_key: bytes, 可选
    :param peer_public_key: 对方的公钥，用于计算共享密钥。
    :type peer_public_key: bytes
    :param key_size: 密钥的大小（位）。默认为 2048 位。
    :type key_size: int

    :return: 包含计算得到的共享密钥以及相关参数的测试数据对象。
    :rtype: DhTestData

    :example:
    >>> p = b'...'  
    >>> g = b'...'  
    >>> private_key = b'...'  
    >>> peer_public_key = b'...'  
    >>> shared_key_data = generate_dh_shared_key(p=p, g=g, private_key=private_key, peer_public_key=peer_public_key)  
    >>> print(shared_key_data.shared_key)
    """
    # 1. 生成大素数和生成元
    if p is None:
        p = getrandbits(key_size).to_bytes((key_size + 7) // 8, 'big')
    if g is None:
        g = (2).to_bytes(1, 'big')

    # 2. 本地私钥和公钥
    if private_key is None:
        private_key = getrandbits(key_size // 2).to_bytes((key_size // 2 + 7) // 8, 'big')

    p_int = int.from_bytes(p, 'big')
    g_int = int.from_bytes(g, 'big')
    private_key_int = int.from_bytes(private_key, 'big')

    public_key = pow(g_int, private_key_int, p_int)

    # 3. 对方公钥（如果是 None，则自动生成）
    if peer_public_key is None:
        peer_private_key = getrandbits(key_size // 2).to_bytes((key_size // 2 + 7) // 8, 'big')
        peer_public_key_int = pow(g_int, int.from_bytes(peer_private_key, 'big'), p_int)
        peer_public_key = peer_public_key_int.to_bytes((peer_public_key_int.bit_length() + 7) // 8, 'big')

    else:
        peer_public_key_int = int.from_bytes(peer_public_key, 'big')

    # 4. 计算共享密钥
    shared_secret = pow(peer_public_key_int, private_key_int, p_int)
    shared_key = SHA256.new(shared_secret.to_bytes((shared_secret.bit_length() + 7) // 8, 'big')).digest()

    # 返回 DhTestData，所有字段均为 bytes 类型
    return DhTestData(
        p=p,
        g=g,
        private_key=private_key,
        public_key=public_key.to_bytes((public_key.bit_length() + 7) // 8, 'big'),
        peer_public_key=peer_public_key,
        shared_key=shared_key
    )

def compute_shared_key(private_key: bytes, peer_public_key: bytes, p: bytes) -> bytes:
    """
    计算 Diffie-Hellman 密钥交换的共享密钥。

    该函数使用给定的私钥、对方的公钥以及质数模数 `p` 来计算 Diffie-Hellman 密钥交换的共享密钥。

    :param private_key: 用于密钥交换的私钥。
    :type private_key: bytes
    :param peer_public_key: 对方的公钥。
    :type peer_public_key: bytes
    :param p: 用于 Diffie-Hellman 密钥交换的质数模数。
    :type p: bytes

    :return: 计算得到的共享密钥。
    :rtype: bytes

    :example:
    >>> private_key = b'...'  
    >>> peer_public_key = b'...'  
    >>> p = b'...'  
    >>> shared_key = compute_shared_key(private_key, peer_public_key, p)  
    >>> print(shared_key)
    """
    # 将字节数据转换成整数
    private_key_int = int.from_bytes(private_key, 'big')
    peer_public_key_int = int.from_bytes(peer_public_key, 'big')
    p_int = int.from_bytes(p, 'big')

    # 计算共享密钥
    shared_secret = pow(peer_public_key_int, private_key_int, p_int)

    # 返回共享密钥的哈希值（SHA256）
    return SHA256.new(
        shared_secret.to_bytes((shared_secret.bit_length() + 7) // 8, 'big')
    ).digest()
