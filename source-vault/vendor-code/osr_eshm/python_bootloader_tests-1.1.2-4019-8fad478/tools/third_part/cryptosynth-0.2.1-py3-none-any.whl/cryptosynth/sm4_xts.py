"""
SM4 XTS模式实现
基于IEEE 1619标准 - XEX-based tweaked-codebook mode with ciphertext stealing
"""

import struct
from typing import Union
from gmssl.sm4 import CryptSM4, SM4_ENCRYPT, SM4_DECRYPT
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes


class SM4XTS:
    """SM4 XTS (XEX-based tweaked-codebook mode with ciphertext stealing) 模式实现"""
    
    def __init__(self, key: bytes):
        """
        初始化SM4 XTS
        
        :param key: SM4密钥，32字节（key1 16字节 + key2 16字节）
        """
        if len(key) != 32:
            raise ValueError("SM4 XTS key must be 32 bytes (key1 + key2)")
            
        self.key1 = key[:16]   # 数据加密密钥
        self.key2 = key[16:]   # tweak加密密钥
    
    def _xor_bytes(self, a: bytes, b: bytes) -> bytes:
        """字节异或运算"""
        return bytes(x ^ y for x, y in zip(a, b))
    
    def _sm4_ecb_decrypt(self, key: bytes, ciphertext: bytes) -> bytes:
        """使用cryptography库做SM4 ECB解密，因为gmssl的ECB解密有问题"""
        algorithm = algorithms.SM4(key)
        mode = modes.ECB()
        cipher = Cipher(algorithm, mode)
        decryptor = cipher.decryptor()
        result = decryptor.update(ciphertext) + decryptor.finalize()
        return result
    
    def _multiply_by_alpha(self, tweak: bytes) -> bytes:
        """
        在GF(2^128)中乘以α (primitive element)
        α = x，在GF(2^128)中表示为最低位为1的多项式
        """
        # 将16字节转换为128位整数（小端序）
        val = int.from_bytes(tweak, 'little')
        
        # 左移一位
        val <<= 1
        
        # 如果溢出128位，需要模约化多项式 x^128 + x^7 + x^2 + x + 1
        if val & (1 << 128):
            val ^= (1 << 128) | (1 << 7) | (1 << 2) | (1 << 1) | 1
        
        # 转换回16字节（小端序）
        return (val & ((1 << 128) - 1)).to_bytes(16, 'little')
    
    def _generate_tweaks(self, initial_tweak: bytes, num_blocks: int) -> list:
        """
        生成所有块的tweak值
        第i个块的tweak = α^i * initial_tweak
        """
        tweaks = []
        current_tweak = initial_tweak
        
        for i in range(num_blocks):
            tweaks.append(current_tweak)
            if i < num_blocks - 1:  # 最后一个不需要计算下一个
                current_tweak = self._multiply_by_alpha(current_tweak)
        
        return tweaks
    
    def encrypt(self, tweak: bytes, plaintext: bytes) -> bytes:
        """
        XTS加密
        
        :param tweak: tweak值，16字节（通常是扇区号等）
        :param plaintext: 明文，至少16字节
        :return: 密文
        """
        if len(plaintext) < 16:
            raise ValueError("Plaintext must be at least 16 bytes for XTS")
        
        if len(tweak) != 16:
            raise ValueError("Tweak must be 16 bytes")
        
        # 初始化SM4实例
        sm4_tweak = CryptSM4()
        sm4_tweak.set_key(self.key2, SM4_ENCRYPT)
        sm4_data = CryptSM4()
        sm4_data.set_key(self.key1, SM4_ENCRYPT)
        
        # 用key2加密tweak得到初始tweak值
        encrypted_tweak = sm4_tweak.crypt_ecb(tweak)[:16]
        
        # 计算完整块数和剩余字节数
        full_blocks = len(plaintext) // 16
        remaining_bytes = len(plaintext) % 16
        
        result = b''
        
        if remaining_bytes == 0:
            # 没有不完整块，直接处理所有完整块
            tweaks = self._generate_tweaks(encrypted_tweak, full_blocks)
            
            for i in range(full_blocks):
                block = plaintext[i*16:(i+1)*16]
                # XEX: plaintext XOR tweak, encrypt, XOR tweak
                pre_encrypt = self._xor_bytes(block, tweaks[i])
                encrypted = sm4_data.crypt_ecb(pre_encrypt)[:16]
                post_encrypt = self._xor_bytes(encrypted, tweaks[i])
                result += post_encrypt
        else:
            # 有不完整块，需要使用Ciphertext Stealing
            if full_blocks == 0:
                raise ValueError("XTS requires at least one full block when using ciphertext stealing")
            
            # 处理前n-1个完整块
            tweaks = self._generate_tweaks(encrypted_tweak, full_blocks)
            
            for i in range(full_blocks - 1):
                block = plaintext[i*16:(i+1)*16]
                pre_encrypt = self._xor_bytes(block, tweaks[i])
                encrypted = sm4_data.crypt_ecb(pre_encrypt)[:16]
                post_encrypt = self._xor_bytes(encrypted, tweaks[i])
                result += post_encrypt
            
            # 处理最后一个完整块和不完整块（Ciphertext Stealing）
            last_full_block = plaintext[(full_blocks-1)*16:full_blocks*16]
            partial_block = plaintext[full_blocks*16:]
            
            # 先加密最后一个完整块
            pre_encrypt = self._xor_bytes(last_full_block, tweaks[full_blocks-1])
            encrypted = sm4_data.crypt_ecb(pre_encrypt)[:16]
            cc = self._xor_bytes(encrypted, tweaks[full_blocks-1])
            
            # Ciphertext Stealing：取cc的前remaining_bytes作为最终密文的一部分
            final_partial = cc[:remaining_bytes]
            
            # 构造倒数第二个块的输入：partial_block || cc[remaining_bytes:]
            pp = partial_block + cc[remaining_bytes:]
            
            # 用相同的tweak加密
            pre_encrypt2 = self._xor_bytes(pp, tweaks[full_blocks-1])
            encrypted2 = sm4_data.crypt_ecb(pre_encrypt2)[:16]
            final_full = self._xor_bytes(encrypted2, tweaks[full_blocks-1])
            
            result += final_full + final_partial
        
        return result
    
    def decrypt(self, tweak: bytes, ciphertext: bytes) -> bytes:
        """
        XTS解密
        
        :param tweak: tweak值，16字节（必须与加密时相同）
        :param ciphertext: 密文，至少16字节
        :return: 明文
        """
        if len(ciphertext) < 16:
            raise ValueError("Ciphertext must be at least 16 bytes for XTS")
        
        if len(tweak) != 16:
            raise ValueError("Tweak must be 16 bytes")
        
        # 初始化SM4实例
        sm4_tweak = CryptSM4()
        sm4_tweak.set_key(self.key2, SM4_ENCRYPT)  # tweak总是用加密模式
        sm4_data = CryptSM4()
        sm4_data.set_key(self.key1, SM4_DECRYPT)   # 数据解密用解密模式
        
        # 用key2加密tweak得到初始tweak值
        encrypted_tweak = sm4_tweak.crypt_ecb(tweak)[:16]
        
        # 计算完整块数和剩余字节数
        full_blocks = len(ciphertext) // 16
        remaining_bytes = len(ciphertext) % 16
        
        result = b''
        
        if remaining_bytes == 0:
            # 没有不完整块
            tweaks = self._generate_tweaks(encrypted_tweak, full_blocks)
            
            for i in range(full_blocks):
                block = ciphertext[i*16:(i+1)*16]
                # XEX解密: ciphertext XOR tweak, decrypt, XOR tweak
                pre_decrypt = self._xor_bytes(block, tweaks[i])
                decrypted = self._sm4_ecb_decrypt(self.key1, pre_decrypt)
                post_decrypt = self._xor_bytes(decrypted, tweaks[i])
                result += post_decrypt
        else:
            # 有不完整块，需要使用Ciphertext Stealing
            if full_blocks == 0:
                raise ValueError("XTS requires at least one full block when using ciphertext stealing")
            
            tweaks = self._generate_tweaks(encrypted_tweak, full_blocks)
            
            # 处理前n-1个完整块
            for i in range(full_blocks - 1):
                block = ciphertext[i*16:(i+1)*16]
                pre_decrypt = self._xor_bytes(block, tweaks[i])
                decrypted = self._sm4_ecb_decrypt(self.key1, pre_decrypt)
                post_decrypt = self._xor_bytes(decrypted, tweaks[i])
                result += post_decrypt
            
            # 处理最后的完整块和不完整块（Ciphertext Stealing）
            last_full_block = ciphertext[(full_blocks-1)*16:full_blocks*16]
            partial_block = ciphertext[full_blocks*16:]
            
            # 先解密最后一个完整块
            pre_decrypt = self._xor_bytes(last_full_block, tweaks[full_blocks-1])
            decrypted = self._sm4_ecb_decrypt(self.key1, pre_decrypt)
            pp = self._xor_bytes(decrypted, tweaks[full_blocks-1])
            
            # Ciphertext Stealing：构造原始的最后完整块
            cc = partial_block + pp[remaining_bytes:]
            
            # 解密得到原始最后完整块
            pre_decrypt2 = self._xor_bytes(cc, tweaks[full_blocks-1])
            decrypted2 = self._sm4_ecb_decrypt(self.key1, pre_decrypt2)
            original_last_full = self._xor_bytes(decrypted2, tweaks[full_blocks-1])
            
            # 原始部分块
            original_partial = pp[:remaining_bytes]
            
            result += original_last_full + original_partial
        
        return result