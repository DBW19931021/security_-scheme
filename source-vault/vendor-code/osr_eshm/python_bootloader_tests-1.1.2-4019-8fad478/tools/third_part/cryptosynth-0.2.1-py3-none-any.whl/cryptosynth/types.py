# -*- coding:utf-8 -*-

# 此文件定义数据类型

from dataclasses import dataclass


@dataclass
class SymmetricTestData:
    """对称加密测试数据集"""
    algo: str
    mode: str
    padding: str
    key: bytes
    plaintext: bytes
    ciphertext: bytes
    iv_nonce: bytes = b""  # IV 或 nonce 根据模式不同使用
    aad: bytes = b""
    auth_tag: bytes = b""  # GCM 模式认证标签
    source: str = "auto_generate" # 数据来源

@dataclass
class HashTestData:
    """hash数据集"""
    algo: str
    plaintext: bytes
    digest: bytes
    source: str = "auto_generate" # 数据来源

@dataclass
class HmacTestData:
    """hmac数据集"""
    algo: str
    key: bytes
    plaintext: bytes
    digest: bytes
    source: str = "auto_generate" # 数据来源


@dataclass
class RsaSignTestData:
    data: bytes
    mode: str
    e: bytes
    n: bytes
    d: bytes
    signature: bytes
    hash_alg: str =None
    p: bytes = b""
    q: bytes = b""
    dP: bytes = b""
    dQ: bytes = b""
    qInv: bytes = b""
    salt: bytes = b""
    alg: str  = ""                    #rsa算法(RSA1024/2048/3072/4096)
    source: str = "auto_generate" # 数据来源

@dataclass
class RsaEncryptTestData:
    plaintext: bytes       # 明文
    ciphertext: bytes      # 密文
    mode: str              # 加密模式 ("PKCS1V15" 或 "OAEP")
    e: bytes               # 公钥指数
    n: bytes               # 模数
    hash_alg: str =""          # OAEP 模式下使用的哈希算法
    d: bytes = b""         # 私钥指数
    p: bytes = b""         # 素数 p (CRT 参数)
    q: bytes = b""         # 素数 q (CRT 参数)
    dP: bytes = b""        # d mod (p-1)
    dQ: bytes = b""        # d mod (q-1)
    qInv: bytes = b""      # q^(-1) mod p
    seed: bytes = b""      # PKCS1V15 模式下使用的seed
    label: bytes = b""     # OAEP 模式下使用的标签
    alg: str =""              # rsa算法(RSA1024/2048/3072/4096)
    source: str = "auto_generate" # 数据来源

@dataclass
class Sm2SignTestData:
    data: bytes         # E值
    private_key: bytes  # 32 bytes
    public_key: bytes   # 64 bytes (x||y)
    signature: bytes    # ASN.1 DER 编码格式
    rand_k: bytes
    source: str = "auto_generate" # 数据来源


@dataclass
class Sm2EncryptTestData:
    data: bytes
    public_key: bytes   # 64字节（未压缩：x||y）
    private_key: bytes  # 32字节（十六进制私钥）
    ciphertext: bytes   # GM/T 0009 加密结果
    rand_k: bytes
    source: str = "auto_generate" # 数据来源


@dataclass
class DhTestData:
    p: bytes
    g: bytes
    private_key: bytes
    public_key: bytes
    peer_public_key: bytes
    shared_key: bytes

@dataclass
class DhPairTestData:
    p: bytes
    g: bytes
    a_private_key: bytes
    a_public_key: bytes
    b_private_key: bytes
    b_public_key: bytes
    shared_key: bytes

@dataclass
class EcdhTestData:
    curve: str
    private_key: bytes
    public_key: bytes
    peer_public_key: bytes
    shared_key: bytes
    source: str = "auto_generate" # 数据来源
@dataclass
class EcdhPairTestData:
    curve: str
    a_private_key: bytes
    a_public_key: bytes
    b_private_key: bytes
    b_public_key: bytes
    shared_key: bytes
    source: str = "auto_generate" # 数据来源
@dataclass
class EccSignTestData:
    data: bytes
    private_key: bytes
    signature: bytes
    curve: str
    hash_alg: str
    params: bytes = None            # rand_k
    public_key: bytes = None
    algorithm: str = "ECDSA"
    digest: bytes = None            # 添加: 哈希值
    scheme: str = None              # EdDSA scheme: "Ed25519", "Ed25519ph", "Ed448", "Ed448ph"
    source: str = "auto_generate"   # 数据来源

@dataclass
class Sm9KeyAgreementTestData:
    """SM9密钥协商测试数据"""
    id_a: str  # 用户A的标识
    id_b: str  # 用户B的标识
    master_public_key: bytes  # SM9主公钥对象（序列化）
    master_private_key: bytes  # SM9主私钥
    user_private_key_a: bytes  # 用户A的私钥（序列化）
    user_private_key_b: bytes  # 用户B的私钥（序列化）
    ephemeral_a: bytes  # 用户A的临时密钥对（序列化）
    ephemeral_b: bytes  # 用户B的临时密钥对（序列化）
    session_key_a: str  # 用户A生成的会话密钥
    session_key_b: str  # 用户B生成的会话密钥
    key_length: int  # 密钥长度（位）
    source: str = "auto_generate"  # 数据来源

@dataclass  
class Sm9AuthTestData:
    """SM9身份认证测试数据（基于签名的身份认证）"""
    challenger_id: str  # 挑战者标识
    prover_id: str  # 证明者标识
    challenge: bytes  # 认证挑战
    master_public_key: bytes  # SM9主公钥对象（序列化）
    master_private_key: bytes  # SM9主私钥
    prover_private_key: bytes  # 证明者私钥（序列化）
    auth_response: bytes  # 认证响应（签名，序列化）
    timestamp: int  # 时间戳（可选）
    source: str = "auto_generate"  # 数据来源