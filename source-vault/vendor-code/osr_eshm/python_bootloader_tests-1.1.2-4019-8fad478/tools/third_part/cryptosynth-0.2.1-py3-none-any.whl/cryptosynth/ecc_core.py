# P-192	NIST P-192 / secp192r1
# P-224	NIST P-224 / secp224r1
# P-256	NIST P-256 / secp256r1 ✅ 默认
# P-384	NIST P-384 / secp384r1
# P-521	NIST P-521 / secp521r1
# secp256k1	Bitcoin 使用的曲线
# brainpoolP256r1（部分平台）	德国 Brainpool 推荐曲线
# ECDSA/ED25519/ED448
from typing import Union, Optional
from dataclasses import dataclass
from secrets import token_bytes
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, ed448
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature, encode_dss_signature
from cryptography.hazmat.primitives import serialization
from .types import EccSignTestData
from cryptography.exceptions import InvalidSignature

from cryptography.hazmat.primitives.asymmetric.ec import (
    SECP192R1, SECP224R1, SECP256R1, SECP384R1, SECP521R1,
    SECP256K1,
    BrainpoolP256R1,BrainpoolP384R1, BrainpoolP512R1
)
from .extended_ecc import extended_ecc, KoblitzPoint
import ecdsa

def get_curve_obj(curve: str):
    # 对于cryptography库支持的曲线
    cryptography_curves = {
        "secp192r1": SECP192R1(),
        "secp224r1": SECP224R1(),
        "secp256r1": SECP256R1(),
        "secp384r1": SECP384R1(),
        "secp521r1": SECP521R1(),
        "secp256k1": SECP256K1(),
        "brainpool256r1": BrainpoolP256R1(),
        "brainpool384r1": BrainpoolP384R1(),
        "brainpool512r1": BrainpoolP512R1()
    }
    
    # 对于扩展支持的曲线
    extended_curves = {
        "secp192k1": extended_ecc.secp192k1,
        "secp224k1": extended_ecc.secp224k1,
        "brainpool224r1": ecdsa.BRAINPOOLP224r1,
        "brainpool320r1": ecdsa.BRAINPOOLP320r1,
    }
    
    curve_lower = curve.lower()
    if curve_lower in cryptography_curves:
        return cryptography_curves[curve_lower]
    elif curve_lower in extended_curves:
        return extended_curves[curve_lower]
    else:
        return None

def generate_ecc_sign_testdata(
    data: Union[bytes, int] = 1024,
    algorithm: str = "ECDSA",
    curve: str = "secp256r1",
    private_key: bytes = None,
    public_key: bytes = None,
    hash_alg: str = "SHA256",
    scheme: str = None
) -> EccSignTestData:
    """
    生成 ECC 签名测试数据。

    该函数根据提供的参数生成 ECC 签名所需的测试数据，包括算法、曲线、私钥、公钥、
    哈希算法等，用于后续的签名和验签测试。

    :param data: 用于签名的消息数据。若提供整数，将生成该长度的随机数据。默认为 1024。
    :type data: bytes 或 int
    :param algorithm: 使用的签名算法。默认为 "ECDSA"。
    :type algorithm: str
    :param curve: 使用的椭圆曲线。默认为 "secp256r1"。
    :type curve: str
    :param private_key: 用于签名的私钥。如果未提供，将自动生成。
    :type private_key: bytes, 可选
    :param public_key: 用于验签的公钥。如果未提供，将从私钥生成。
    :type public_key: bytes, 可选
    :param hash_alg: 用于签名的哈希算法。默认为 "SHA256"。
    :type hash_alg: str
    :param scheme: EdDSA 的 scheme 类型。可选值: None(自动), "Ed25519", "Ed25519ph", "Ed448", "Ed448ph"
    :type scheme: str, 可选

    :return: 包含生成的签名测试数据（包括消息数据、签名算法、曲线、私钥、公钥等）。
    :rtype: EccSignTestData

    :example:
    >>> private_key = b'...'
    >>> public_key = b'...'
    >>> sign_data = generate_ecc_sign_testdata(private_key=private_key, public_key=public_key)
    >>> print(sign_data.signature)
    """
    if isinstance(data, int):
        data = token_bytes(data)

    hash_algorithm = {
        "MD5": hashes.MD5(),
        "SHA1": hashes.SHA1(),
        "SHA224": hashes.SHA224(),
        "SHA256": hashes.SHA256(),
        "SHA384": hashes.SHA384(),
        "SHA512": hashes.SHA512(),
        
    }.get(hash_alg)
    if not hash_algorithm:
        raise ValueError(f"Unsupported hash algorithm: {hash_alg}")

    hasher = hashes.Hash(hash_algorithm)
    hasher.update(data)
    digest = hasher.finalize()

    if algorithm == "ECDSA":
        curve_obj = get_curve_obj(curve)
        if not curve_obj:
            raise ValueError(f"Unsupported ECDSA curve: {curve}")
        
        # 处理Koblitz曲线 (secp192k1, secp224k1)
        if curve.lower() in ['secp192k1', 'secp224k1']:
            if private_key:
                priv_int = int.from_bytes(private_key, "big")
            else:
                priv_int, _ = curve_obj.generate_keypair()
            
            pub_point = curve_obj.point_multiply(priv_int, curve_obj.G)
            raw_signature = extended_ecc.generate_koblitz_signature(data, priv_int, curve, hash_alg)
            
            private_key_bytes = priv_int.to_bytes((curve_obj.key_size + 7) // 8, 'big')
            public_key_bytes = curve_obj.point_to_bytes(pub_point)
            
        # 处理Brainpool曲线 (brainpool224r1, brainpool320r1)
        elif curve.lower() in ['brainpool224r1', 'brainpool320r1']:
            priv_bytes, pub_bytes, raw_signature = extended_ecc.generate_brainpool_signature(
                data, curve, private_key, hash_alg
            )
            private_key_bytes = priv_bytes
            # Brainpool公钥需要加上04前缀以保持一致性
            public_key_bytes = b'\x04' + pub_bytes
            
        # 处理cryptography库支持的曲线
        else:
            print("private_key:",private_key.hex() if private_key else "None")
            if private_key:
                print("private_key3:",int.from_bytes(private_key, "big"))
            private_key_obj = (
                ec.derive_private_key(int.from_bytes(private_key, "big"), curve_obj)
                if private_key else ec.generate_private_key(curve_obj)
            )
            public_key_obj = private_key_obj.public_key()

            der_signature = private_key_obj.sign(data, ec.ECDSA(hash_algorithm))
            r, s = decode_dss_signature(der_signature)

            r_bytes = r.to_bytes((curve_obj.key_size + 7) // 8, 'big')
            s_bytes = s.to_bytes((curve_obj.key_size + 7) // 8, 'big')
            raw_signature = r_bytes + s_bytes

            priv_int = private_key_obj.private_numbers().private_value
            private_key_bytes = priv_int.to_bytes((priv_int.bit_length() + 7) // 8, 'big')

            pub_numbers = public_key_obj.public_numbers()
            pub_x = pub_numbers.x.to_bytes((curve_obj.key_size + 7) // 8, 'big')
            pub_y = pub_numbers.y.to_bytes((curve_obj.key_size + 7) // 8, 'big')
            public_key_bytes = b'\x04' + pub_x + pub_y

    elif algorithm == "EdDSA":
        # Reason: 确定 scheme，如果未指定则使用默认值
        if scheme is None:
            scheme = curve  # 默认使用纯模式："Ed25519" 或 "Ed448"

        # Reason: 验证 scheme 和 curve 的组合是否有效
        valid_schemes = {
            "Ed25519": ["Ed25519", "Ed25519ph"],
            "Ed448": ["Ed448", "Ed448ph"]
        }
        if curve not in valid_schemes or scheme not in valid_schemes[curve]:
            raise ValueError(f"Invalid scheme '{scheme}' for curve '{curve}'")

        # Reason: EdDSA 使用固定的哈希算法，根据曲线类型设置
        if curve == "Ed25519":
            hash_alg = "SHA512"  # Ed25519 使用 SHA-512
        else:  # Ed448
            hash_alg = "SHAKE256"  # Ed448 使用 SHAKE256

        # Reason: 检查是否为预哈希模式
        is_prehashed = scheme.endswith("ph")

        if is_prehashed:
            # Reason: Ed25519ph/Ed448ph 使用 PyCryptodome 实现（符合 RFC 8032）
            from Crypto.PublicKey import ECC as PyCrypto_ECC
            from Crypto.Signature import eddsa
            from Crypto.Hash import SHA512, SHAKE256

            # 生成或加载私钥
            if curve == "Ed25519":
                if private_key:
                    key_obj = PyCrypto_ECC.import_key(
                        b'-----BEGIN PRIVATE KEY-----\n' +
                        __import__('base64').b64encode(
                            b'\x30\x2e\x02\x01\x00\x30\x05\x06\x03\x2b\x65\x70\x04\x22\x04\x20' + private_key
                        ) + b'\n-----END PRIVATE KEY-----\n'
                    )
                else:
                    key_obj = PyCrypto_ECC.generate(curve='ed25519')
                # Ed25519ph 使用 SHA-512 预哈希
                prehashed_message = SHA512.new(data)
            else:  # Ed448
                if private_key:
                    key_obj = PyCrypto_ECC.import_key(
                        b'-----BEGIN PRIVATE KEY-----\n' +
                        __import__('base64').b64encode(
                            b'\x30\x47\x02\x01\x00\x30\x05\x06\x03\x2b\x65\x71\x04\x3b\x04\x39' + private_key
                        ) + b'\n-----END PRIVATE KEY-----\n'
                    )
                else:
                    key_obj = PyCrypto_ECC.generate(curve='ed448')
                # Ed448ph 使用 SHAKE256(512 bits) 预哈希
                prehashed_message = SHAKE256.new(data).read(64)

            # 使用 PyCryptodome 进行签名
            signer = eddsa.new(key_obj, 'rfc8032')
            raw_signature = signer.sign(prehashed_message)

            # Reason: 从 DER 编码中提取原始私钥和公钥字节
            # PyCryptodome 不支持直接以 'raw' 格式导出，需要从 DER 格式中提取
            private_key_der = key_obj.export_key(format='DER')
            public_key_der = key_obj.public_key().export_key(format='DER')

            if curve == "Ed25519":
                # Ed25519 私钥: DER 格式中最后 32 字节
                private_key_bytes = private_key_der[-32:]
                # Ed25519 公钥: DER 格式中最后 32 字节
                public_key_bytes = public_key_der[-32:]
            else:  # Ed448
                # Ed448 私钥: DER 格式中最后 57 字节
                private_key_bytes = private_key_der[-57:]
                # Ed448 公钥: DER 格式中最后 57 字节
                public_key_bytes = public_key_der[-57:]

        else:
            # Reason: 纯 Ed25519/Ed448 使用 pyca/cryptography 实现
            if curve == "Ed25519":
                private_key_obj = (
                    ed25519.Ed25519PrivateKey.from_private_bytes(private_key)
                    if private_key else ed25519.Ed25519PrivateKey.generate()
                )
            elif curve == "Ed448":
                private_key_obj = (
                    ed448.Ed448PrivateKey.from_private_bytes(private_key)
                    if private_key else ed448.Ed448PrivateKey.generate()
                )
            else:
                raise ValueError(f"Unsupported EdDSA curve: {curve}")

            public_key_obj = private_key_obj.public_key()
            raw_signature = private_key_obj.sign(data)

            private_key_bytes = private_key_obj.private_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PrivateFormat.Raw,
                encryption_algorithm=serialization.NoEncryption()
            )
            public_key_bytes = public_key_obj.public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw
            )
    else:
        raise ValueError(f"Unsupported algorithm: {algorithm}")

    return EccSignTestData(
        data=data,
        private_key=private_key_bytes,
        public_key=public_key_bytes,
        signature=raw_signature,
        algorithm=algorithm,
        curve=curve,
        hash_alg=hash_alg,
        digest=digest,
        scheme=scheme
    )

def verify_ecc_signature(data: Optional[bytes] = None,
                         signature: Optional[bytes] = None,
                         public_key: Optional[bytes] = None,
                         testdata: Optional[EccSignTestData] = None,
                         algorithm: str = "ECDSA",
                         curve: str = "secp256r1",
                         hash_alg: str = "SHA256",
                         scheme: str = None) -> bool:
    """
    验证 ECC 签名。

    该函数根据提供的数据、签名、公钥及其他相关参数来验证 ECC 签名的有效性。
    支持不同的签名算法、椭圆曲线和哈希算法。

    :param data: 用于验证签名的消息数据。如果未提供，则从 `testdata` 中获取。
    :type data: bytes, 可选
    :param signature: 要验证的签名。如果未提供，则从 `testdata` 中获取。
    :type signature: bytes, 可选
    :param public_key: 用于验证签名的公钥。如果未提供，将从 `testdata` 中获取。
    :type public_key: bytes, 可选
    :param testdata: 一个包含签名数据、私钥、公钥、消息等的测试数据对象。如果提供，将优先使用其中的数据。
    :type testdata: EccSignTestData, 可选
    :param algorithm: 使用的签名算法，默认为 "ECDSA"。
    :type algorithm: str
    :param curve: 使用的椭圆曲线，默认为 "secp256r1"。
    :type curve: str
    :param hash_alg: 用于签名的哈希算法，默认为 "SHA256"。
    :type hash_alg: str
    :param scheme: EdDSA 的 scheme 类型。可选值: None(自动), "Ed25519", "Ed25519ph", "Ed448", "Ed448ph"
    :type scheme: str, 可选

    :return: 如果签名验证成功，则返回 True；如果签名无效，则返回 False。
    :rtype: bool

    :example:
    >>> public_key = b'...'
    >>> data = b'...'
    >>> signature = b'...'
    >>> result = verify_ecc_signature(data=data, signature=signature, public_key=public_key)
    >>> print(result)
    True  # 如果签名有效
    """
    if testdata:
        data = testdata.data
        signature = testdata.signature
        public_key = testdata.public_key
        algorithm = testdata.algorithm
        curve = testdata.curve
        hash_alg = testdata.hash_alg
        scheme = testdata.scheme
        print("data:",data,"\n")
        print("signature:",signature,"\n")
        print("public_key:",public_key,"\n")
    try:
        if algorithm == "ECDSA":
            curve_obj = get_curve_obj(curve)
            if not curve_obj:
                raise ValueError(f"Unsupported ECDSA curve: {curve}")

            # 处理Koblitz曲线 (secp192k1, secp224k1)
            if curve.lower() in ['secp192k1', 'secp224k1']:
                # 从字节串恢复公钥点
                pub_point = curve_obj.bytes_to_point(public_key)
                return extended_ecc.verify_koblitz_signature(data, signature, pub_point, curve, hash_alg)
                
            # 处理Brainpool曲线 (brainpool224r1, brainpool320r1)
            elif curve.lower() in ['brainpool224r1', 'brainpool320r1']:
                # 移除04前缀
                pub_key_data = public_key[1:] if public_key[0] == 0x04 else public_key
                return extended_ecc.verify_brainpool_signature(data, signature, pub_key_data, curve, hash_alg)
                
            # 处理cryptography库支持的曲线
            else:
                hash_algorithm = {
                    "MD5": hashes.MD5(),
                    "SHA1": hashes.SHA1(),
                    "SHA224": hashes.SHA224(),
                    "SHA256": hashes.SHA256(),
                    "SHA384": hashes.SHA384(),
                    "SHA512": hashes.SHA512(),
                }.get(hash_alg)
                if not hash_algorithm:
                    raise ValueError(f"Unsupported hash algorithm: {hash_alg}")

                key_len = (curve_obj.key_size + 7) // 8
                if len(public_key) != 1 + 2 * key_len or public_key[0] != 0x04:
                    raise ValueError("Invalid uncompressed public key format")

                x = int.from_bytes(public_key[1:1 + key_len], 'big')
                y = int.from_bytes(public_key[1 + key_len:], 'big')
                pub_numbers = ec.EllipticCurvePublicNumbers(x, y, curve_obj)
                public_key_obj = pub_numbers.public_key()

                if len(signature) != 2 * key_len:
                    raise ValueError("Invalid raw signature format")
                r = int.from_bytes(signature[:key_len], 'big')
                s = int.from_bytes(signature[key_len:], 'big')
                der_signature = encode_dss_signature(r, s)

                public_key_obj.verify(der_signature, data, ec.ECDSA(hash_algorithm))

        elif algorithm == "EdDSA":
            # Reason: 确定 scheme，如果未指定则使用默认值
            if scheme is None:
                scheme = curve  # 默认使用纯模式

            # Reason: 检查是否为预哈希模式
            is_prehashed = scheme.endswith("ph")

            if is_prehashed:
                # Reason: Ed25519ph/Ed448ph 使用 PyCryptodome 验证（符合 RFC 8032）
                from Crypto.PublicKey import ECC as PyCrypto_ECC
                from Crypto.Signature import eddsa
                from Crypto.Hash import SHA512, SHAKE256

                # 导入公钥
                if curve == "Ed25519":
                    # Ed25519 公钥格式
                    key_obj = PyCrypto_ECC.import_key(
                        b'-----BEGIN PUBLIC KEY-----\n' +
                        __import__('base64').b64encode(
                            b'\x30\x2a\x30\x05\x06\x03\x2b\x65\x70\x03\x21\x00' + public_key
                        ) + b'\n-----END PUBLIC KEY-----\n'
                    )
                    # Ed25519ph 使用 SHA-512 预哈希
                    prehashed_message = SHA512.new(data)
                else:  # Ed448
                    # Ed448 公钥格式
                    key_obj = PyCrypto_ECC.import_key(
                        b'-----BEGIN PUBLIC KEY-----\n' +
                        __import__('base64').b64encode(
                            b'\x30\x43\x30\x05\x06\x03\x2b\x65\x71\x03\x3a\x00' + public_key
                        ) + b'\n-----END PUBLIC KEY-----\n'
                    )
                    # Ed448ph 使用 SHAKE256(512 bits) 预哈希
                    prehashed_message = SHAKE256.new(data).read(64)

                # 使用 PyCryptodome 验证签名
                verifier = eddsa.new(key_obj, 'rfc8032')
                verifier.verify(prehashed_message, signature)

            else:
                # Reason: 纯 Ed25519/Ed448 使用 pyca/cryptography 验证
                if curve == "Ed25519":
                    public_key_obj = ed25519.Ed25519PublicKey.from_public_bytes(public_key)
                elif curve == "Ed448":
                    public_key_obj = ed448.Ed448PublicKey.from_public_bytes(public_key)
                else:
                    raise ValueError(f"Unsupported EdDSA curve: {curve}")
                public_key_obj.verify(signature, data)

        else:
            raise ValueError(f"Unsupported algorithm: {algorithm}")

        return True

    except InvalidSignature:
        return False
    except Exception as e:
        print(f"Verification failed: {e}")
        return False
    
# def ecc_pub_from_pri(algorithm: str = "ECDSA",
#                     curve: str = "secp256r1",
#                     private_key: bytes = None,
#                     )->public_key:
    
#     if algorithm == "ECDSA":
#         curve_obj = get_curve_obj(curve)
#         if not curve_obj:
#             raise ValueError(f"Unsupported ECDSA curve: {curve}")

#         private_key_obj = (
#             ec.derive_private_key(int.from_bytes(private_key, "big"), curve_obj)
#             if private_key else ec.generate_private_key(curve_obj)
#         )
#         public_key_obj = private_key_obj.public_key()
#         pub_numbers = public_key_obj.public_numbers()
#         pub_x = pub_numbers.x.to_bytes((curve_obj.key_size + 7) // 8, 'big')
#         pub_y = pub_numbers.y.to_bytes((curve_obj.key_size + 7) // 8, 'big')
#         public_key_bytes = b'\x04' + pub_x + pub_y

#     elif algorithm == "EdDSA":
#         if curve == "Ed25519":
#             private_key_obj = (
#                 ed25519.Ed25519PrivateKey.from_private_bytes(private_key)
#                 if private_key else ed25519.Ed25519PrivateKey.generate()
#             )
#         elif curve == "Ed448":
#             private_key_obj = (
#                 ed448.Ed448PrivateKey.from_private_bytes(private_key)
#                 if private_key else ed448.Ed448PrivateKey.generate()
#             )
#         else:
#             raise ValueError(f"Unsupported EdDSA curve: {curve}")

#         public_key_obj = private_key_obj.public_key()
#         public_key_bytes = public_key_obj.public_bytes(
#         encoding=serialization.Encoding.Raw,
#         format=serialization.PublicFormat.Raw
#         )
#     public_key=public_key_bytes
#     return public_key