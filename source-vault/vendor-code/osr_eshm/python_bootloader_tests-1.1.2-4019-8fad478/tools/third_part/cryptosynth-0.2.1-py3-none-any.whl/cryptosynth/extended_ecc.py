"""
扩展椭圆曲线支持
为PKE算法添加secp192k1, secp224k1, brainpool224r1, brainpool320r1曲线支持
"""

import secrets
import hashlib
from typing import Tuple, Optional, Union
from dataclasses import dataclass
import ecdsa


class KoblitzPoint:
    """Koblitz椭圆曲线点(secp192k1, secp224k1)"""
    
    def __init__(self, x: Optional[int] = None, y: Optional[int] = None):
        self.x = x
        self.y = y
        self.is_infinity = (x is None and y is None)
    
    def __eq__(self, other):
        if not isinstance(other, KoblitzPoint):
            return False
        return self.x == other.x and self.y == other.y and self.is_infinity == other.is_infinity
    
    def __repr__(self):
        if self.is_infinity:
            return "KoblitzPoint(∞)"
        return f"KoblitzPoint({hex(self.x)}, {hex(self.y)})"


class KoblitzCurve:
    """Koblitz椭圆曲线基类"""
    
    def __init__(self, p: int, a: int, b: int, n: int, gx: int, gy: int):
        self.p = p  # 素数模
        self.a = a  # 曲线参数a (对于Koblitz曲线通常为0)
        self.b = b  # 曲线参数b 
        self.n = n  # 子群阶
        self.gx = gx  # 基点x坐标
        self.gy = gy  # 基点y坐标
        self.G = KoblitzPoint(gx, gy)
    
    def _mod_inverse(self, a: int, m: int) -> int:
        """计算模逆"""
        return pow(a, m - 2, m)
    
    def _tonelli_shanks(self, n: int, p: int) -> Optional[int]:
        """Tonelli-Shanks算法计算模p的平方根"""
        if pow(n, (p - 1) // 2, p) != 1:
            return None  # n不是二次剩余
        
        # 找Q和S，使得p-1 = Q * 2^S且Q为奇数
        Q = p - 1
        S = 0
        while Q % 2 == 0:
            Q //= 2
            S += 1
        
        if S == 1:
            return pow(n, (p + 1) // 4, p)
        
        # 找一个二次非剩余z
        z = 2
        while pow(z, (p - 1) // 2, p) != p - 1:
            z += 1
        
        M = S
        c = pow(z, Q, p)
        t = pow(n, Q, p)
        R = pow(n, (Q + 1) // 2, p)
        
        while t != 1:
            # 找最小的i使得t^(2^i) ≡ 1 (mod p)
            i = 1
            temp = (t * t) % p
            while temp != 1:
                temp = (temp * temp) % p
                i += 1
            
            b = pow(c, 1 << (M - i - 1), p)
            M = i
            c = (b * b) % p
            t = (t * c) % p
            R = (R * b) % p
        
        return R
    
    def point_add(self, P: KoblitzPoint, Q: KoblitzPoint) -> KoblitzPoint:
        """椭圆曲线点加法"""
        if P.is_infinity:
            return Q
        if Q.is_infinity:
            return P
        
        if P.x == Q.x:
            if P.y == Q.y:
                return self.point_double(P)
            else:
                return KoblitzPoint()  # 无穷远点
        
        s = ((Q.y - P.y) * self._mod_inverse(Q.x - P.x, self.p)) % self.p
        x3 = (s * s - P.x - Q.x) % self.p
        y3 = (s * (P.x - x3) - P.y) % self.p
        
        return KoblitzPoint(x3, y3)
    
    def point_double(self, P: KoblitzPoint) -> KoblitzPoint:
        """椭圆曲线点倍乘"""
        if P.is_infinity:
            return P
        
        if P.y == 0:
            return KoblitzPoint()  # 无穷远点
        
        s = ((3 * P.x * P.x + self.a) * self._mod_inverse(2 * P.y, self.p)) % self.p
        x3 = (s * s - 2 * P.x) % self.p
        y3 = (s * (P.x - x3) - P.y) % self.p
        
        return KoblitzPoint(x3, y3)
    
    def point_multiply(self, k: int, P: KoblitzPoint) -> KoblitzPoint:
        """椭圆曲线点数乘 k*P"""
        if k == 0:
            return KoblitzPoint()  # 无穷远点
        
        if k == 1:
            return P
        
        if k < 0:
            raise ValueError("k must be positive")
        
        result = KoblitzPoint()  # 无穷远点
        addend = P
        
        while k:
            if k & 1:
                result = self.point_add(result, addend)
            addend = self.point_double(addend)
            k >>= 1
        
        return result
    
    def generate_keypair(self) -> Tuple[int, KoblitzPoint]:
        """生成密钥对"""
        while True:
            d = secrets.randbits(self.key_size)
            if 1 <= d < self.n:
                break
        
        P = self.point_multiply(d, self.G)
        return d, P
    
    def point_to_bytes(self, point: KoblitzPoint) -> bytes:
        """将椭圆曲线点转换为字节串(未压缩格式)"""
        if point.is_infinity:
            return b'\x00'
        
        coord_size = (self.key_size + 7) // 8
        x_bytes = point.x.to_bytes(coord_size, 'big')
        y_bytes = point.y.to_bytes(coord_size, 'big')
        
        return b'\x04' + x_bytes + y_bytes
    
    def bytes_to_point(self, data: bytes) -> KoblitzPoint:
        """将字节串转换为椭圆曲线点"""
        if len(data) == 1 and data[0] == 0:
            return KoblitzPoint()  # 无穷远点
        
        coord_size = (self.key_size + 7) // 8
        expected_len = 1 + 2 * coord_size
        
        if len(data) == expected_len and data[0] == 0x04:
            x = int.from_bytes(data[1:1 + coord_size], 'big')
            y = int.from_bytes(data[1 + coord_size:], 'big')
            return KoblitzPoint(x, y)
        else:
            raise ValueError(f"Invalid point data format, length: {len(data)}")


class SECP192K1(KoblitzCurve):
    """secp192k1 Koblitz曲线"""
    
    def __init__(self):
        # secp192k1参数
        p = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFEE37
        a = 0
        b = 3
        n = 0xFFFFFFFFFFFFFFFFFFFFFFFE26F2FC170F69466A74DEFD8D
        gx = 0xDB4FF10EC057E9AE26B07D0280B7F4341DA5D1B1EAE06C7D
        gy = 0x9B2F2F6D9C5628A7844163D015BE86344082AA88D95E2F9D
        
        super().__init__(p, a, b, n, gx, gy)
        self.key_size = 192


class SECP224K1(KoblitzCurve):
    """secp224k1 Koblitz曲线 (注意：此曲线在标准中可能未正式定义)"""
    
    def __init__(self):
        # secp224k1参数 (模拟实现，基于secp224r1修改为Koblitz形式)
        p = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFE56D
        a = 0
        b = 5
        n = 0x10000000000000000000000000001DCE8D2EC6184CAF0A971769FB1F7
        
        # 计算一个满足椭圆曲线方程的基点
        # 搜索满足 y^2 = x^3 + 5 (mod p) 的点
        gx = 0xA1455B334DF099DF30FC28A169A467E9E47075A90F7E650EB6B7A45C
        gy = 0x7E089FED7FBA344282CAFBD6F7E319F7C0B0BD59E2CA4BDB556D61A5

        super().__init__(p, a, b, n, gx, gy)
        self.key_size = 224


class ExtendedECCWrapper:
    """扩展ECC包装器，统一不同椭圆曲线的接口"""
    
    def __init__(self):
        self.secp192k1 = SECP192K1()
        self.secp224k1 = SECP224K1()

    def _truncate_hash(self, digest: bytes, n_bits: int) -> int:
        """
        根据ECDSA标准截断hash摘要

        :param digest: hash摘要字节串
        :param n_bits: 曲线子群阶n的位长度
        :return: 截断后的整数值

        # Reason: FIPS 186-4标准要求当hash长度超过曲线阶位长度时进行截断
        """
        hash_int = int.from_bytes(digest, 'big')
        hash_bits = len(digest) * 8

        if hash_bits > n_bits:
            # 截断：右移多余的位
            shift = hash_bits - n_bits
            hash_int >>= shift

        return hash_int

    def get_curve(self, curve_name: str):
        """获取椭圆曲线对象"""
        curve_map = {
            'secp192k1': self.secp192k1,
            'secp224k1': self.secp224k1,
            'brainpoolp224r1': ecdsa.BRAINPOOLP224r1,
            'brainpool224r1': ecdsa.BRAINPOOLP224r1,
            'brainpoolp320r1': ecdsa.BRAINPOOLP320r1,
            'brainpool320r1': ecdsa.BRAINPOOLP320r1,
        }
        return curve_map.get(curve_name.lower())
    
    def generate_koblitz_signature(self, message: bytes, private_key: int, 
                                   curve_name: str, hash_alg: str = "SHA256") -> bytes:
        """为Koblitz曲线生成签名"""
        curve = self.get_curve(curve_name)
        if not isinstance(curve, KoblitzCurve):
            raise ValueError(f"Not a Koblitz curve: {curve_name}")
        
        # 哈希消息
        hash_func = getattr(hashlib, hash_alg.lower())
        digest = hash_func(message).digest()
        # Reason: 使用截断函数确保符合ECDSA标准（FIPS 186-4）
        hash_int = self._truncate_hash(digest, curve.n.bit_length())
        
        # 生成签名 (简化的ECDSA)
        while True:
            k = secrets.randbelow(curve.n - 1) + 1
            point = curve.point_multiply(k, curve.G)
            r = point.x % curve.n
            if r == 0:
                continue
            
            k_inv = curve._mod_inverse(k, curve.n)
            s = (k_inv * (hash_int + r * private_key)) % curve.n
            if s == 0:
                continue
            
            # 返回DER格式签名
            # Reason: 使用 n.bit_length() 而不是 key_size，因为 n 的位长度可能与 key_size 不同
            coord_size = (curve.n.bit_length() + 7) // 8
            r_bytes = r.to_bytes(coord_size, 'big')
            s_bytes = s.to_bytes(coord_size, 'big')
            return r_bytes + s_bytes
    
    def verify_koblitz_signature(self, message: bytes, signature: bytes, 
                                 public_key: KoblitzPoint, curve_name: str,
                                 hash_alg: str = "SHA256") -> bool:
        """验证Koblitz曲线签名"""
        curve = self.get_curve(curve_name)
        if not isinstance(curve, KoblitzCurve):
            raise ValueError(f"Not a Koblitz curve: {curve_name}")
        
        try:
            # Reason: 使用 n.bit_length() 而不是 key_size，因为 n 的位长度可能与 key_size 不同
            coord_size = (curve.n.bit_length() + 7) // 8
            if len(signature) != 2 * coord_size:
                return False
            
            r = int.from_bytes(signature[:coord_size], 'big')
            s = int.from_bytes(signature[coord_size:], 'big')
            
            if r == 0 or s == 0 or r >= curve.n or s >= curve.n:
                return False
            
            # 哈希消息
            hash_func = getattr(hashlib, hash_alg.lower())
            digest = hash_func(message).digest()
            # Reason: 使用截断函数确保符合ECDSA标准（FIPS 186-4）
            hash_int = self._truncate_hash(digest, curve.n.bit_length())

            # 验证签名
            s_inv = curve._mod_inverse(s, curve.n)
            u1 = (hash_int * s_inv) % curve.n
            u2 = (r * s_inv) % curve.n
            
            point1 = curve.point_multiply(u1, curve.G)
            point2 = curve.point_multiply(u2, public_key)
            point = curve.point_add(point1, point2)
            
            if point.is_infinity:
                return False
            
            return (point.x % curve.n) == r
            
        except Exception:
            return False
    
    def generate_brainpool_signature(self, message: bytes, curve_name: str,
                                     private_key_bytes: Optional[bytes] = None,
                                     hash_alg: str = "SHA256") -> Tuple[bytes, bytes, bytes]:
        """为Brainpool曲线生成签名"""
        ecdsa_curve = self.get_curve(curve_name)
        if not hasattr(ecdsa_curve, 'generator'):
            raise ValueError(f"Not a valid Brainpool curve: {curve_name}")
        
        if private_key_bytes:
            sk = ecdsa.SigningKey.from_string(private_key_bytes, curve=ecdsa_curve)
        else:
            sk = ecdsa.SigningKey.generate(curve=ecdsa_curve)
        
        vk = sk.get_verifying_key()
        
        hash_func = getattr(hashlib, hash_alg.lower())
        signature = sk.sign(message, hashfunc=hash_func)
        
        return sk.to_string(), vk.to_string(), signature
    
    def verify_brainpool_signature(self, message: bytes, signature: bytes,
                                   public_key_bytes: bytes, curve_name: str,
                                   hash_alg: str = "SHA256") -> bool:
        """验证Brainpool曲线签名"""
        try:
            ecdsa_curve = self.get_curve(curve_name)
            if not hasattr(ecdsa_curve, 'generator'):
                raise ValueError(f"Not a valid Brainpool curve: {curve_name}")
            
            vk = ecdsa.VerifyingKey.from_string(public_key_bytes, curve=ecdsa_curve)
            hash_func = getattr(hashlib, hash_alg.lower())
            
            vk.verify(signature, message, hashfunc=hash_func)
            return True
            
        except Exception:
            return False


# 全局实例
extended_ecc = ExtendedECCWrapper()