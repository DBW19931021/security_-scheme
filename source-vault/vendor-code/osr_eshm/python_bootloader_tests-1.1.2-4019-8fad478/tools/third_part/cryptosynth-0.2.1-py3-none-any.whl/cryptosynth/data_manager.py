import importlib.util
import inspect
from dataclasses import asdict, dataclass, is_dataclass, fields
from typing import Any, Dict, List, Type
import pandas as pd
import os
from .types import (
    SymmetricTestData,
    HmacTestData,
    HashTestData,
    RsaSignTestData,
    RsaEncryptTestData,
    Sm2EncryptTestData,
    Sm2SignTestData,
    DhTestData,
    EcdhTestData,
    EccSignTestData
)  # 导入相关的测试数据结构


class DataManager:
    def __init__(self):
        self.datasets: Dict[str, List[Any]] = {}
        self.data = []

    def add_data(self, data: Any):
        if not is_dataclass(data):
            raise ValueError("Only dataclass instances can be added")
        class_name = type(data).__name__
        self.datasets.setdefault(class_name, []).append(data)
        self.data.append(data)

    def load_from_pyfile(self, filepath: str):
        """
        从 py 文件中导入测试数据
        :param filepath: 要导入的文件名
        """
        module_name = os.path.splitext(os.path.basename(filepath))[0]
        spec = importlib.util.spec_from_file_location(module_name, filepath)
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            for name, obj in inspect.getmembers(module):
                if is_dataclass(obj) and not isinstance(obj, type):
                    self.add_data(obj)

    def print_all_data(self):
        """
        打印所有的内部数据
        """
        for class_name, data_list in self.datasets.items():
            print(f"\n== {class_name} ==")
            for idx, item in enumerate(data_list, 1):
                print(f"  [{idx}]")
                for field in item.__dataclass_fields__:
                    value = getattr(item, field)
                    if isinstance(value, bytes):
                        hex_str = value.hex()
                        print(f"    {field}: {hex_str}")
                    else:
                        print(f"    {field}: {value}")


    def generate_py_test_data(self, filename: str):
        """
        生成 Python 测试数据文件
        :param filename: 要生成的文件名（路径）
        """
        if not filename.endswith(".py"):
            filename += ".py"
        
        with open(filename, "w") as f:
            f.write("from cryptosynth import SymmetricTestData, HmacTestData, HashTestData, RsaSignTestData, RsaEncryptTestData, Sm2EncryptTestData, Sm2SignTestData, DhTestData, EcdhTestData, EccSignTestData\n")
            f.write("from typing import List\n\n")

            for class_name, data_list in self.datasets.items():
                f.write(f"{class_name.lower()}_data: List[{class_name}] = [\n")
                for entry in data_list:
                    f.write(f"    {class_name}(\n")
                    for field in fields(entry):
                        value = getattr(entry, field.name)
                        if isinstance(value, bytes):
                            f.write(f"        {field.name}=bytes([")
                            f.write(', '.join([f"0x{b:02x}" for b in value]))
                            f.write("]),\n")
                        elif isinstance(value, str):
                            f.write(f"        {field.name}=\"{value}\",  # {value}\n")
                        elif isinstance(value, list):
                            f.write(f"        {field.name}=list({value}),\n")
                        else:
                            f.write(f"        {field.name}={value},  # {value}\n")
                    f.write(f"    ),\n")
                f.write("]\n\n")

        print(f"Generated Python test data file: {filename}")

    def generate_h_file(self, filename: str):
        """
        生成 头文件 .h 测试数据文件
        :param filename: 要生成的文件名（路径）
        """
        lines = ['// Auto-generated header file\n']

        for class_name, data_list in self.datasets.items():
            struct_name = class_name.lower()
            example = data_list[0]
            
            # 结构体定义
            lines.append(f"typedef struct {struct_name}_t {{")
            for field in example.__dataclass_fields__.values():
                c_type = self._get_c_type(field.type)
                lines.append(f"    {c_type} {field.name};")
            lines.append(f"}} {struct_name}_t;\n")

            # 数据定义
            lines.append(f"static const {struct_name}_t {struct_name}_data[] = {{")
            for item in data_list:
                lines.append("    {")
                for field in item.__dataclass_fields__:
                    value = getattr(item, field)
                    formatted, hex_comment = self._format_field(value, indent=8)
                    lines.append(f"        .{field} = {formatted},")
                    if hex_comment:
                        lines.append(f"        /* {field} = {hex_comment} */")
                lines.append("    },")
            lines.append("};\n")

        with open(filename, "w") as f:
            f.write("\n".join(lines))


    def _get_c_type(self, py_type):
        origin = getattr(py_type, '__origin__', None)
        if py_type == bytes:
            return "const char *"
        elif py_type == int:
            return "int"
        elif py_type == str:
            return "const char *"
        return "const char *"  # fallback

    def _format_field(self, value, indent=8):
        if isinstance(value, bytes):
            if not value:
                return '""', None
            hex_str = ''.join(f'\\x{b:02x}' for b in value)
            hex_comment = value.hex()
            lines = [f'"{hex_str[i:i+64]}"' for i in range(0, len(hex_str), 64)]
            return '\n' + '\n'.join((' ' * indent) + l for l in lines), hex_comment
        elif isinstance(value, str):
            return f'"{value}"' if value else '""', None
        elif isinstance(value, int):
            return str(value), None
        else:
            return "NULL", None

    def export_to_excel(self, filename: str):
        """
        生成 excel 格式测试数据文件
        :param filename: 要生成的文件名（路径）
        """
        all_data = []

        for class_name, data_list in self.datasets.items():
            for item in data_list:
                row = {"__class__": class_name}
                for field in item.__dataclass_fields__:
                    value = getattr(item, field)
                    if isinstance(value, bytes):
                        hex_str = value.hex()
                        row[field] = hex_str
                        row[f"{field}_len"] = len(value)
                    elif isinstance(value, str):
                        row[field] = value
                    elif isinstance(value, int):
                        row[field] = value
                    else:
                        row[field] = str(value)
                all_data.append(row)

        df = pd.DataFrame(all_data)
        df.to_excel(filename, index=False)
