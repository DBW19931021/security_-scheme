"""
纯Python SM2椭圆曲线运算实现
用于替换gmssl中不稳定的椭圆曲线点运算部分
"""

import secrets
from typing import Tuple, Optional


class SM2Point:
    """SM2椭圆曲线点"""
    
    def __init__(self, x: Optional[int] = None, y: Optional[int] = None):
        self.x = x
        self.y = y
        self.is_infinity = (x is None and y is None)
    
    def __eq__(self, other):
        if not isinstance(other, SM2Point):
            return False
        return self.x == other.x and self.y == other.y and self.is_infinity == other.is_infinity
    
    def __repr__(self):
        if self.is_infinity:
            return "SM2Point(∞)"
        return f"SM2Point({hex(self.x)}, {hex(self.y)})"


class PureSM2ECC:
    """纯Python SM2椭圆曲线运算类"""
    
    def __init__(self):
        # SM2标准椭圆曲线参数 (GB/T 32918.1-2016)
        self.p = 0xFFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFF
        self.a = 0xFFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFC  
        self.b = 0x28E9FA9E9D9F5E344D5A9E4BCF6509A7F39789F515AB8F92DDBCBD414D940E93
        self.n = 0xFFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFF7203DF6B21C6052B53BBF40939D54123
        self.gx = 0x32C4AE2C1F1981195F9904466A39C9948FE30BBFF2660BE1715A4589334C74C7
        self.gy = 0xBC3736A2F4F6779C59BDCEE36B692153D0A9877CC62A474002DF32E52139F0A0
        self.G = SM2Point(self.gx, self.gy)
    
    def _mod_inverse(self, a: int, m: int) -> int:
        """计算模逆"""
        return pow(a, m - 2, m)
    
    def point_add(self, P: SM2Point, Q: SM2Point) -> SM2Point:
        """椭圆曲线点加法"""
        if P.is_infinity:
            return Q
        if Q.is_infinity:
            return P
        
        if P.x == Q.x:
            if P.y == Q.y:
                # 点倍乘
                return self.point_double(P)
            else:
                # P + (-P) = O
                return SM2Point()  # 无穷远点
        
        # P ≠ Q的情况
        s = ((Q.y - P.y) * self._mod_inverse(Q.x - P.x, self.p)) % self.p
        x3 = (s * s - P.x - Q.x) % self.p
        y3 = (s * (P.x - x3) - P.y) % self.p
        
        return SM2Point(x3, y3)
    
    def point_double(self, P: SM2Point) -> SM2Point:
        """椭圆曲线点倍乘"""
        if P.is_infinity:
            return P
        
        if P.y == 0:
            return SM2Point()  # 无穷远点
        
        s = ((3 * P.x * P.x + self.a) * self._mod_inverse(2 * P.y, self.p)) % self.p
        x3 = (s * s - 2 * P.x) % self.p
        y3 = (s * (P.x - x3) - P.y) % self.p
        
        return SM2Point(x3, y3)
    
    def point_multiply(self, k: int, P: SM2Point) -> SM2Point:
        """椭圆曲线点数乘 k*P"""
        if k == 0:
            return SM2Point()  # 无穷远点
        
        if k == 1:
            return P
        
        if k < 0:
            raise ValueError("k must be positive")
        
        # 使用二进制方法进行点乘
        result = SM2Point()  # 无穷远点
        addend = P
        
        while k:
            if k & 1:
                result = self.point_add(result, addend)
            addend = self.point_double(addend)
            k >>= 1
        
        return result
    
    def generate_keypair(self) -> Tuple[int, SM2Point]:
        """生成SM2密钥对"""
        # 生成私钥 d ∈ [1, n-1]
        while True:
            d = secrets.randbits(256)
            if 1 <= d < self.n:
                break
        
        # 计算公钥 P = d*G
        P = self.point_multiply(d, self.G)
        
        return d, P
    
    def point_to_bytes(self, point: SM2Point, compressed: bool = False) -> bytes:
        """将椭圆曲线点转换为字节串"""
        if point.is_infinity:
            return b'\x00'
        
        x_bytes = point.x.to_bytes(32, 'big')
        y_bytes = point.y.to_bytes(32, 'big')
        
        if compressed:
            # 压缩格式：02/03 + x坐标
            prefix = b'\x02' if point.y % 2 == 0 else b'\x03'
            return prefix + x_bytes
        else:
            # 未压缩格式：04 + x坐标 + y坐标
            return b'\x04' + x_bytes + y_bytes
    
    def bytes_to_point(self, data: bytes) -> SM2Point:
        """将字节串转换为椭圆曲线点"""
        if len(data) == 1 and data[0] == 0:
            return SM2Point()  # 无穷远点
        
        if len(data) == 65 and data[0] == 0x04:
            # 未压缩格式
            x = int.from_bytes(data[1:33], 'big')
            y = int.from_bytes(data[33:65], 'big')
            return SM2Point(x, y)
        
        elif len(data) == 64:
            # 64字节格式（无前缀）
            x = int.from_bytes(data[0:32], 'big')
            y = int.from_bytes(data[32:64], 'big')
            return SM2Point(x, y)
        
        elif len(data) == 33 and data[0] in [0x02, 0x03]:
            # 压缩格式（暂不实现，可根据需要添加）
            raise NotImplementedError("Compressed point format not implemented")
        
        else:
            raise ValueError(f"Invalid point data format, length: {len(data)}")
    
    def point_from_hex(self, hex_str: str) -> SM2Point:
        """从十六进制字符串创建椭圆曲线点"""
        if len(hex_str) == 128:
            # 64字节坐标格式
            x = int(hex_str[:64], 16)
            y = int(hex_str[64:], 16)
            return SM2Point(x, y)
        elif len(hex_str) == 130 and hex_str.startswith('04'):
            # 65字节未压缩格式
            x = int(hex_str[2:66], 16)
            y = int(hex_str[66:], 16)
            return SM2Point(x, y)
        else:
            raise ValueError(f"Invalid hex string format: {hex_str}")
    
    def point_to_hex(self, point: SM2Point) -> str:
        """将椭圆曲线点转换为十六进制字符串（64字节坐标格式）"""
        if point.is_infinity:
            return "00"
        
        x_hex = format(point.x, '064x')
        y_hex = format(point.y, '064x')
        return x_hex + y_hex


# 全局实例
_pure_sm2_ecc = PureSM2ECC()


def generate_random_hex(length: int) -> str:
    """生成指定长度的随机十六进制字符串"""
    byte_length = length // 2
    return secrets.token_hex(byte_length)


def pure_point_multiply(k: int, point_hex: str) -> Optional[str]:
    """
    纯Python椭圆曲线点乘运算
    替换gmssl的CryptSM2._kg方法
    
    :param k: 标量
    :param point_hex: 椭圆曲线点的十六进制表示
    :return: 结果点的十六进制表示，失败返回None
    """
    try:
        # 解析输入点
        point = _pure_sm2_ecc.point_from_hex(point_hex)
        
        # 执行点乘
        result = _pure_sm2_ecc.point_multiply(k, point)
        
        # 转换为十六进制字符串
        return _pure_sm2_ecc.point_to_hex(result)
        
    except Exception:
        return None


def pure_generate_keypair() -> Tuple[str, str]:
    """
    生成SM2密钥对
    
    :return: (私钥十六进制, 公钥十六进制)
    """
    private_key, public_key = _pure_sm2_ecc.generate_keypair()
    
    private_key_hex = format(private_key, '064x')
    public_key_hex = _pure_sm2_ecc.point_to_hex(public_key)
    
    return private_key_hex, public_key_hex


if __name__ == "__main__":
    # 测试代码
    print("测试纯Python SM2椭圆曲线运算...")
    
    # 测试密钥生成
    priv_hex, pub_hex = pure_generate_keypair()
    print(f"私钥: {priv_hex}")
    print(f"公钥: {pub_hex}")
    
    # 测试点乘
    k = 123456789
    g_hex = "32c4ae2c1f1981195f9904466a39c9948fe30bbff2660be1715a4589334c74c7bc3736a2f4f6779c59bdcee36b692153d0a9877cc62a474002df32e52139f0a0"
    result = pure_point_multiply(k, g_hex)
    print(f"点乘结果: {result}")