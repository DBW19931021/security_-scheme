"""
CryptoSynth - Cryptographic Test Data Generation Library
"""

# Data Manager
from .data_manager import DataManager

# Data Types
from .types import (
    SymmetricTestData,
    HashTestData,
    HmacTestData,
    RsaSignTestData,
    RsaEncryptTestData,
    Sm2SignTestData,
    Sm2EncryptTestData,
    DhTestData,
    DhPairTestData,
    EcdhTestData,
    EcdhPairTestData,
    EccSignTestData,
    Sm9KeyAgreementTestData,
    Sm9AuthTestData
)

# DH Key Exchange
from .dh_core import (
    generate_dh_shared_key,
    compute_shared_key
)

# ECDH Key Exchange
from .ecdh_core import (
    generate_ecdh_shared_key,
)

# ECC Elliptic Curve
from .ecc_core import (
    generate_ecc_sign_testdata,
    verify_ecc_signature,
    get_curve_obj
)

# Hash Algorithms
from .hash_core import (
    generate_hash_testdata,
    generate_hmac_testdata
)

# RSA Algorithm
from .rsa_core import (
    generate_rsa_sign_testdata,
    verify_rsa_signature,
    generate_rsa_encrypt_testdata,
    verify_rsa_decryption
)

# Symmetric Encryption
from .ske_core import (
    generate_symmetric_testdata,
    verify_symmetric_testdata
)

# SM2 Algorithm
from .sm2_core import (
    generate_sm2_sign_testdata,
    verify_sm2_signature,
    generate_sm2_encrypt_testdata,
    decrypt_sm2_ciphertext
)

# SM9 Algorithm
from .sm9_core import (
    generate_sm9_sign_testdata,
    verify_sm9_signature,
    generate_sm9_encrypt_testdata,
    sm9_decrypt_data,
    generate_sm9_keyagreement_testdata,
    verify_sm9_keyagreement,
    generate_sm9_auth_testdata,
    verify_sm9_auth
)

__version__ = "0.2.1"
__author__ = "CryptoSynth Team"