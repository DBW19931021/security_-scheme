import hashlib
import hmac
from typing import Union
from cryptosynth.types import HashTestData
from cryptosynth.types import HmacTestData
from gmssl import sm3, func
from secrets import token_bytes

def generate_hash_testdata(
    algo: str,
    plaintext: bytes | int = 1024,
) -> HashTestData:
    """
    生成指定算法的哈希测试数据。

    :param algo: 哈希算法名称，如 'MD5', 'SHA1', 'SHA2-256', 'SHA3-512' 等。
    :param plaintext: 原始数据，默认为 1024 字节的整数数据。
    :return: HashTestData 对象，包含算法、明文和哈希值。
    """
    # 如果 plaintext 是整数，转换为字节串
    if isinstance(plaintext, int):
        plaintext = token_bytes(plaintext)

    # 使用 hashlib 根据算法生成哈希值
    try:
        if algo == 'MD5':
            hash_object = hashlib.md5()
        elif algo == 'SHA1':
            hash_object = hashlib.sha1()
        elif algo == 'SHA2-224':
            hash_object = hashlib.sha224()
        elif algo == 'SHA2-256':
            hash_object = hashlib.sha256()
        elif algo == 'SHA2-384':
            hash_object = hashlib.sha384()
        elif algo == 'SHA2-512':
            hash_object = hashlib.sha512()
        elif algo == 'SHA2-512/224':
            hash_object = hashlib.new('sha512_224')
        elif algo == 'SHA2-512/256':
            hash_object = hashlib.new('sha512_256')
        elif algo == 'SM3':
            digest_hex = sm3.sm3_hash(func.bytes_to_list(plaintext))  # 返回十六进制字符串
            digest = bytes.fromhex(digest_hex)  # 将十六进制字符串转换为字节
            return HashTestData(algo=algo, plaintext=plaintext, digest=digest)
        elif algo == 'SHA3-224':
            hash_object = hashlib.sha3_224()
        elif algo == 'SHA3-256':
            hash_object = hashlib.sha3_256()
        elif algo == 'SHA3-384':
            hash_object = hashlib.sha3_384()
        elif algo == 'SHA3-512':
            hash_object = hashlib.sha3_512()
        elif algo == 'SHAKE-128':
            hash_object = hashlib.shake_128()
        elif algo == 'SHAKE-256':
            hash_object = hashlib.shake_256()
        else:
            raise ValueError(f"Unsupported algorithm: {algo}")

        # 更新哈希对象并计算哈希值
        hash_object.update(plaintext)

        # 如果是 SHAKE 算法，指定输出长度（例如 64 字节）
        if algo.startswith('SHAKE'):
            if algo == 'SHAKE-128':
                digest = hash_object.digest(32)  # 可调整长度
            elif algo == 'SHAKE-256':
                digest = hash_object.digest(64)  # 可调整长度
        else:
            digest = hash_object.digest()

        return HashTestData(algo=algo, plaintext=plaintext, digest=digest)

    except Exception as e:
        raise ValueError(f"Error while generating hash: {e}")


def generate_hmac_testdata(
    algo: str,
    key: bytes | int = 1024,
    plaintext: bytes | int = 1024,
) -> HmacTestData:
    """
    生成指定算法和密钥的 HMAC 测试数据。

    :param algo: 哈希算法名称，如 'MD5', 'SHA1', 'SHA2-256' 等。
    :param key: 用于 HMAC 的密钥。
    :param plaintext: 明文，默认为 1024 字节的整数数据。
    :return: HmacTestData 对象，包含算法、密钥、明文和 HMAC 值。
    """
    # 如果 plaintext 是整数，转换为字节串
    if isinstance(plaintext, int):
        plaintext = token_bytes(plaintext)

    if isinstance(key, int):
        key = token_bytes(key)

    # 根据算法选择合适的哈希函数
    try:
        if algo == 'MD5':
            hash_function = hashlib.md5
        elif algo == 'SHA1':
            hash_function = hashlib.sha1
        elif algo == 'SHA2-224':
            hash_function = hashlib.sha224
        elif algo == 'SHA2-256':
            hash_function = hashlib.sha256
        elif algo == 'SHA2-384':
            hash_function = hashlib.sha384
        elif algo == 'SHA2-512':
            hash_function = hashlib.sha512
        elif algo == 'SHA2-512/224':
            hash_function = lambda: hashlib.new('sha512_224')
        elif algo == 'SHA2-512/256':
            hash_function = lambda: hashlib.new('sha512_256')
        elif algo == 'SM3':
            block_size = 64  # SM3 块大小为 64 字节
            original_key = key
            if len(key) > block_size:
                key = bytes.fromhex(sm3.sm3_hash(func.bytes_to_list(key)))
            if len(key) < block_size:
                key = key + b'\x00' * (block_size - len(key))

            o_key_pad = bytes([b ^ 0x5C for b in key])
            i_key_pad = bytes([b ^ 0x36 for b in key])

            inner = i_key_pad + plaintext
            inner_hash = bytes.fromhex(sm3.sm3_hash(func.bytes_to_list(inner)))

            outer = o_key_pad + inner_hash
            digest = bytes.fromhex(sm3.sm3_hash(func.bytes_to_list(outer)))
            return HmacTestData(algo=algo, key=original_key, plaintext=plaintext, digest=digest)
        elif algo == 'SHA3-224':
            hash_function = hashlib.sha3_224
        elif algo == 'SHA3-256':
            hash_function = hashlib.sha3_256
        elif algo == 'SHA3-384':
            hash_function = hashlib.sha3_384
        elif algo == 'SHA3-512':
            hash_function = hashlib.sha3_512
        elif algo == 'SHAKE-128':
            hash_function = hashlib.shake_128
        elif algo == 'SHAKE-256':
            hash_function = hashlib.shake_256
        else:
            raise ValueError(f"Unsupported algorithm: {algo}")

        # 生成 HMAC 对象并计算 HMAC
        if algo.startswith('SHAKE'):
            raise ValueError(f"HMAC is not supported for algorithm: {algo}")
        hmac_object = hmac.new(key, plaintext, hash_function)
        digest = hmac_object.digest()

        return HmacTestData(algo=algo, key=key, plaintext=plaintext, digest=digest)

    except Exception as e:
        raise ValueError(f"Error while generating HMAC: {e}")