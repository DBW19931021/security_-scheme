#!/usr/bin/env python3
# -*- coding:utf-8-*-
"""
Safe transport protocol over UART
"""

import time
import serial
from typing import Callable
from loguru import logger as log

OFF_LEAD0 = 0
OFF_TYPE = 1
OFF_LEN = 2
OFF_PAYLOAD = 3

FRAME_LEAD = b"\x5a"

STRING_FRAME_LEAD1 = 0xFE
STRING_FRAME_LEAD2 = 0xF0
STRING_FRAME_END1 = 0xFE
STRING_FRAME_END2 = 0xFE

STRING_BUFFER_SIZE = 1024

TYPE_DATA = 0x10  # data frame
TYPE_ACK = 0x20  # ack frame
TYPE_SWITCH = 0x40  # switch from send to recv mode reuqest frame
TYPE_RESYNC_REQ = 0x08  # re-sync req frame
TYPE_RESYNC_ACK = 0x04  # re-sync ack frame
TYPE_ERR = 0x80  # err frame
TYPE_MASK = 0xFC

ERR_CODE_CRC = 0x01
ERR_CODE_CHAR_TIMEOUT = 0x02
ERR_CODE_TYPE = 0x03
ERR_CODE_MASK = 0x03

MAX_PAYLOAD_SIZE = 255
MAX_FRAME_SIZE = 260
MAX_ERR_COUNT = 5

CRC_INIT = b"\x12\x34"

BLOCK_TIMEOUT = 3000
BYTE_TIMEOUT = 0.5


class STPTimeoutError(Exception):
    pass


class STPCrcError(Exception):
    pass


class STPResync(Exception):
    pass


class STPResyncFailed(Exception):
    pass


class STPError(Exception):
    pass


def calc_crc(data: bytes | bytearray) -> bytes:
    val = 0x0000
    poly = 0x1021
    wchar = 0

    for c in data:
        wchar = c
        val ^= (wchar << 8) & 0xFFFF
        for _ in range(8):
            if val & 0x8000:
                val = ((val << 1) & 0xFFFF) ^ poly
            else:
                val = (val << 1) & 0xFFFF
    return val.to_bytes(2, "big")


class STPUart:
    def __init__(
        self,
        is_client: bool,
        port: str,
        baudrate: int = 57600,
        string_callback: Callable[[bytes], None] | None = None,
    ):
        self.__com = serial.Serial(port, baudrate, timeout=0)
        # drop buffer data
        while self.__com.read(1024):
            pass

        # 角色标识
        self.__is_client = is_client
        # 客户端初始为发送模式，服务端初始为接收模式
        self.__send_mode = is_client

        self.__recv_buf = bytearray(MAX_PAYLOAD_SIZE)
        self.__recv_size = 0
        self.__recv_off = 0
        self.__init = True
        self.__string_callback = string_callback

        err_count = 0
        if is_client:
            # 客户端：主动发送RESYNC_REQ建立连接
            while 1:
                if err_count > 5:
                    raise STPError("Client handshake failed")
                # 客户端发送RESYNC_REQ进行握手
                self.send_frame(TYPE_RESYNC_REQ, None)
                try:
                    frame = self.recv_frame()
                    if frame[OFF_TYPE] & TYPE_MASK == TYPE_RESYNC_ACK:
                        log.trace("Client handshake successful")
                        break
                    else:
                        err_count += 1
                        continue
                except (STPCrcError, STPTimeoutError):
                    log.debug("handshake error, retry")
                    err_count += 1
                    continue
        else:
            # 服务端：等待客户端RESYNC_REQ
            log.trace("Server waiting for client handshake")
            # 服务端的握手在__transmit中处理，这里不需要额外逻辑

    def __reset_comm(self):
        """重置通信状态

        根据设备角色重置到初始模式：
        - 客户端：发送模式
        - 服务端：接收模式
        """
        if self.__is_client:
            # 客户端：重置为发送模式（初始模式）
            self.__send_mode = True
        else:
            # 服务端：重置为接收模式（初始模式）
            self.__send_mode = False

        # 清空接收缓冲区
        self.__recv_buf = bytearray(MAX_PAYLOAD_SIZE)
        self.__recv_size = 0
        self.__recv_off = 0
        self.__init = True

        log.trace(
            f"Reset comm: {'client' if self.__is_client else 'server'} mode={'send' if self.__send_mode else 'recv'}"
        )

    def get_com(self):
        """获取底层串口对象

        Returns:
            serial.Serial: 底层串口对象
        """
        return self.__com

    def reset_comm(self):
        """手动重置通信状态（供测试使用）

        根据设备角色重置到初始模式：
        - 客户端：发送模式
        - 服务端：接收模式
        """
        self.__reset_comm()

    def close(self):
        if not self.__send_mode:
            self.send_frame(TYPE_ACK)
            time.sleep(0.1)
        self.__com.close()

    def __del__(self):
        if self.__com:
            try:
                self.__com.close()
            except Exception:
                pass

    def send(self, data: bytes) -> None:
        while not self.__send_mode:
            # 当前处于接收模式，接收并丢弃所有收到的数据，直到对方切换为接收模式
            self.__recv_size = 0
            self.__recv_off = 0
            frame = self.__transmit(TYPE_ACK, None, TYPE_DATA | TYPE_SWITCH)
            if frame[OFF_TYPE] & TYPE_DATA:
                # 收到的是数据帧，丢弃
                continue
            else:
                # 收到的是SWITCH帧，切换为接收模式
                self.__send_mode = True

        size = len(data)
        off = 0
        while size > 0:
            send_len = size if size < MAX_PAYLOAD_SIZE else MAX_PAYLOAD_SIZE
            self.__transmit(TYPE_DATA, data[off : off + send_len], TYPE_ACK)
            size -= send_len
            off += send_len

    def recv(self, size: int) -> bytes:
        ret: list[bytes] = []
        frame = b"\x00" * MAX_FRAME_SIZE
        frame_len = 0
        if self.__send_mode:
            assert self.__recv_size == 0

            # 主动切换到接收模式，直到收到数据帧
            frame = self.__transmit(TYPE_SWITCH, None, TYPE_DATA)
            frame_len = frame[OFF_LEN]
            self.__send_mode = False

        if self.__recv_size > 0:
            copy_len = self.__recv_size if self.__recv_size < size else size
            ret.append(
                bytes(self.__recv_buf[self.__recv_off : self.__recv_off + copy_len])
            )
            size -= copy_len
            self.__recv_size -= copy_len
            self.__recv_off += copy_len

        while size > 0:
            assert self.__recv_size == 0
            assert not self.__send_mode

            if not frame_len:
                frame = self.__transmit(TYPE_ACK, None, TYPE_DATA)

            frame_len = frame[OFF_LEN]
            copy_len = frame_len if frame_len < size else size
            ret.append(frame[OFF_PAYLOAD : OFF_PAYLOAD + copy_len])
            size -= copy_len
            frame_len -= copy_len

        if frame_len > 0:
            self.__recv_buf[0:frame_len] = frame[
                OFF_PAYLOAD + frame[OFF_LEN] - frame_len : OFF_PAYLOAD + frame[OFF_LEN]
            ]
            self.__recv_size = frame_len
            self.__recv_off = 0

        return b"".join(ret)

    def send_string(self, data: bytes) -> None:
        """发送字符串帧

        Args:
            data: 要发送的字符串数据（bytes类型）
        """
        # 构造字符串帧：起始标识 + 数据 + 结束标识
        frame = bytearray()
        frame.append(STRING_FRAME_LEAD1)  # 0xFE
        frame.append(STRING_FRAME_LEAD2)  # 0xF0
        frame.extend(data)  # 字符串内容
        frame.append(STRING_FRAME_END1)  # 0xFE
        frame.append(STRING_FRAME_END2)  # 0xFE

        # 直接发送字符串帧
        self.__com.write(bytes(frame))

        log.trace(f"send string frame: {frame.hex()}")

    def __recv_string_frame(self) -> None:
        """处理字符串帧"""
        try:
            # 已经检测到0xFE，继续检测第二字节是否为0xF0
            val = self.__recv_byte()
            if val[0] != STRING_FRAME_LEAD2:
                # 不是字符串帧，忽略
                return

            log.debug("string frame detected")

            buf = bytearray()
            # 持续读取字符串内容，直到遇到结束标识或超时
            while True:
                try:
                    val = self.__recv_byte()
                except STPTimeoutError:
                    # 超时，输出已收到的内容
                    if len(buf) > 0 and self.__string_callback is not None:
                        self.__string_callback(bytes(buf))
                    return

                # 检测结束标识第一字节
                if val[0] == STRING_FRAME_END1:
                    try:
                        val2 = self.__recv_byte()
                        if val2[0] == STRING_FRAME_END2:
                            # 检测到完整结束标识，输出字符串
                            if len(buf) > 0 and self.__string_callback is not None:
                                self.__string_callback(bytes(buf))
                            log.trace("string frame complete")
                            return
                        else:
                            # 不是结束标识，将两个字节都作为数据
                            # 检查第一个字节是否会导致缓冲区满
                            if len(buf) >= STRING_BUFFER_SIZE - 1:
                                # 缓冲区满，输出当前内容并清空
                                if self.__string_callback is not None:
                                    self.__string_callback(bytes(buf))
                                buf = bytearray()
                            buf.extend(val)

                            # 检查第二个字节是否会导致缓冲区满
                            if len(buf) >= STRING_BUFFER_SIZE - 1:
                                # 缓冲区满，输出当前内容并清空
                                if self.__string_callback is not None:
                                    self.__string_callback(bytes(buf))
                                buf = bytearray()
                            buf.extend(val2)
                    except STPTimeoutError:
                        # 超时，将0xFE作为数据处理
                        if len(buf) >= STRING_BUFFER_SIZE - 1:
                            # 缓冲区满，输出当前内容并清空
                            if self.__string_callback is not None:
                                self.__string_callback(bytes(buf))
                            buf = bytearray()
                        buf.extend(val)
                        if self.__string_callback is not None:
                            self.__string_callback(bytes(buf))
                        return
                else:
                    # 普通字符，检查缓冲区是否会满
                    if len(buf) >= STRING_BUFFER_SIZE - 1:
                        # 缓冲区满，输出当前内容并清空
                        if self.__string_callback is not None:
                            self.__string_callback(bytes(buf))
                        buf = bytearray()
                    buf.extend(val)

        except (STPTimeoutError, STPCrcError):
            # 字符串帧处理中的错误直接忽略
            pass

    def resync(self) -> None:
        """客户端主动重新同步

        重新同步后，客户端将重置为发送模式（初始模式）

        Raises:
            STPError: 如果不是客户端或重新同步失败
        """
        if not self.__is_client:
            raise STPError("Only client can initiate resync")

        log.trace("Client initiating resync")

        err_count = 0
        while 1:
            if err_count > 5:
                raise STPError("Client resync failed")

            # 发送RESYNC_REQ
            self.send_frame(TYPE_RESYNC_REQ, None)

            try:
                frame = self.recv_frame()
                if frame[OFF_TYPE] & TYPE_MASK == TYPE_RESYNC_ACK:
                    log.trace("Client resync successful")
                    # 重置自己的状态
                    self.__reset_comm()
                    return
                else:
                    err_count += 1
                    continue
            except (STPCrcError, STPTimeoutError):
                log.debug("resync error, retry")
                err_count += 1
                continue

    def __transmit(self, type: int, data: bytes | None, expect_type: int) -> bytes:
        assert type in [TYPE_DATA, TYPE_SWITCH, TYPE_ACK]

        if self.__init:
            self.__init = False
            if not self.__send_mode and type == TYPE_ACK:
                pass
            else:
                self.send_frame(type, data)
        else:
            self.send_frame(type, data)

        err_count = 0
        while 1:
            try:
                frame = self.recv_frame()
            except STPTimeoutError as e:
                log.debug("timeout: {}", str(e))
                err_count += 1
                if err_count > 5:
                    raise STPError("more than 5 times error")
                self.send_frame(TYPE_ERR | ERR_CODE_CHAR_TIMEOUT, None)
            except STPCrcError as e:
                log.debug("crc error: {}", str(e))
                err_count += 1
                if err_count > 5:
                    raise STPError("more than 5 times error")
                self.send_frame(TYPE_ERR | ERR_CODE_CRC, None)
            else:
                t = frame[OFF_TYPE] & TYPE_MASK
                if t & expect_type:
                    return frame

                if t == TYPE_ERR:
                    log.debug("recv error frame: {}", t & ERR_CODE_MASK)
                    # resend
                    err_count += 1
                    if err_count > 5:
                        raise STPError("more than 5 times error")
                    self.send_frame(type, data)
                # elif t == TYPE_SWITCH:
                elif t == TYPE_RESYNC_REQ:
                    if self.__is_client:
                        # 客户端不应该收到RESYNC_REQ（只有客户端能发送）
                        log.debug("Client received RESYNC_REQ - protocol violation")
                        err_count += 1
                        if err_count > 5:
                            raise STPError("more than 5 times error")
                        self.send_frame(TYPE_ERR | ERR_CODE_TYPE, None)
                    else:
                        # 服务端：响应RESYNC_REQ
                        log.debug("Server received RESYNC_REQ, sending RESYNC_ACK")
                        self.send_frame(TYPE_RESYNC_ACK, None)
                        # 重置到初始接收模式
                        self.__reset_comm()
                        raise STPResync("server reset by client resync")
                else:
                    log.debug("typeerror: {:02x}", t)
                    err_count += 1
                    if err_count > 5:
                        raise STPError("more than 5 times error")
                    self.send_frame(TYPE_ERR | ERR_CODE_TYPE, None)
        return b""

    def send_frame(self, type: int, data: bytes | None = None):
        assert 0 <= type <= 255
        assert len(data) <= MAX_PAYLOAD_SIZE if data is not None else True

        head = bytearray([FRAME_LEAD[0], type, 0 if not data else len(data)])
        self.__com.write(head)

        if isinstance(data, bytes):
            self.__com.write(data)
            crc = calc_crc(head + data)
        else:
            crc = calc_crc(head)

        log.trace(
            "send frame: {}{}{}", head.hex(), data.hex() if data else "", crc.hex()
        )

        self.__com.write(crc)

    def __recv_byte(self) -> bytes:
        start = time.time()
        while 1:
            b = self.__com.read(1)
            if b:
                return b
            else:
                if time.time() - start >= BYTE_TIMEOUT:
                    raise STPTimeoutError("byte time out")
            time.sleep(0)
        assert 0
        return b""

    def recv_frame(self) -> bytes:
        ret: list[bytes] = []
        start = time.time()
        while 1:
            lead = self.__com.read(1)
            if lead and lead == FRAME_LEAD:
                break
            elif lead and lead[0] == STRING_FRAME_LEAD1:
                # 可能是字符串帧，尝试处理
                self.__recv_string_frame()
                # 处理完字符串帧后继续等待数据帧
                continue
            else:
                if lead:
                    log.trace("recv error lead byte: {}", lead.hex())
                if time.time() - start >= BLOCK_TIMEOUT:
                    raise STPTimeoutError("block time out")
                time.sleep(0)

        ret.append(FRAME_LEAD)
        type = self.__recv_byte()
        ret.append(type)
        data_len = self.__recv_byte()
        ret.append(data_len)

        for _ in range(data_len[0]):
            ret.append(self.__recv_byte())

        crc1 = self.__recv_byte()
        crc2 = self.__recv_byte()

        if crc1 + crc2 != calc_crc(b"".join(ret)):
            log.debug("frame crc error")
            raise STPCrcError("crc error")

        ret.append(crc1)
        ret.append(crc2)
        frame = b"".join(ret)

        log.trace("recv frame: {}", frame.hex())

        return frame
